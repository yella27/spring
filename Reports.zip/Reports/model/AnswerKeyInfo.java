package smartail.deepgrade.reports.model;

import java.util.List;

import org.springframework.data.annotation.Id;

public class AnswerKeyInfo {
	@Id
	public String questionId; 
	public String answer; 
	public List<String> answerImageLink;
	public List<String> correctedAnswerImages;
	public List <String> teacherComments;
	public String rating;
	public String answerId;
	public List<SpellCheck> spellCheck; 
	public List<GrammarError> grammarError; 
	public String contextRating; 
	public String contextComment; 
	public String contextMatch; 
	public int manualCorrection;
	public boolean isCorrected; 

}
