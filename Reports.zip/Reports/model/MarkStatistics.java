package smartail.deepgrade.reports.model;

import java.util.List;

public class MarkStatistics {
	public int notattended;
	public int onestar;
	public int twostar;
	public int threestar;
	public int fourstar;
	public int fivestar;
	
	
	
	public MarkStatistics() {
		super();
		
	}


	

	public MarkStatistics(int notattended, int onestar, int twostar, int threestar, int fourstar, int fivestar) {
		super();
		this.notattended = notattended;
		this.onestar = onestar;
		this.twostar = twostar;
		this.threestar = threestar;
		this.fourstar = fourstar;
		this.fivestar = fivestar;
	}




	public int getNotattended() {
		return notattended;
	}
	public void setNotattended(int notattended) {
		 this.notattended = notattended;
	}
	public int getOnestar() {
		return onestar;
	}
	public void setOnestar(int onestar) {
		 this.onestar = onestar;
	}
	public int getTwostar() {
		return twostar;
	}
	public void setTwostar(int twostar) {
		this.twostar = twostar;
	}
	public int getThreestar() {
		return threestar;
	}
	public void setThreestar(int threestar) {
		this.threestar = threestar;
	}
	public int getFourstar() {
		return fourstar;
	}
	public void setFourstar(int fourstar) {
		this.fourstar = fourstar;
	}
	public int getFivestar() {
		return fivestar;
	}
	public void setFivestar(int fivestar) {
		this.fivestar = fivestar;
	}
	
	@Override
	public String toString() {
		return "MarkStatistics [notattended=" + notattended + ", onestar=" + onestar + ", twostar=" + twostar
				+ ", threestar=" + threestar + ", fourstar=" + fourstar + ", fivestar=" + fivestar + "]";
	}
	

}
