package smartail.deepgrade.reports.model;

import java.util.List;

public class StudentOverAllPercentage {
	public String studentName; 
	public String studentRollnum;
	public int poor;
	public int average;
	public int good;
	public double overAllPercentage;
	public List<QuestionPercentage> individaulpercentage;
	public List<StudentAnalysisAllQuestion> studentAnalysisAllQuestion;
	
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentRollnum() {
		return studentRollnum;
	}
	public void setStudentRollnum(String studentRollnum) {
		this.studentRollnum = studentRollnum;
	}
	public int getPoor() {
		return poor;
	}
	public void setPoor(int poor) {
		this.poor = poor;
	}
	public int getAverage() {
		return average;
	}
	public void setAverage(int average) {
		this.average = average;
	}
	public int getGood() {
		return good;
	}
	public void setGood(int good) {
		this.good = good;
	}
	
	public double getOverAllPercentage() {
		return overAllPercentage;
	}
	public void setOverAllPercentage(double overAllPercentage) {
		this.overAllPercentage = overAllPercentage;
	}
	public List<QuestionPercentage> getIndividaulpercentage() {
		return individaulpercentage;
	}
	public void setIndividaulpercentage(List<QuestionPercentage> individaulpercentage) {
		this.individaulpercentage = individaulpercentage;
	}
	
	public List<StudentAnalysisAllQuestion> getStudentAnalysisAllQuestion() {
		return studentAnalysisAllQuestion;
	}
	public void setStudentAnalysisAllQuestion(List<StudentAnalysisAllQuestion> studentAnalysisAllQuestion) {
		this.studentAnalysisAllQuestion = studentAnalysisAllQuestion;
	}
	
	
	
	
}
