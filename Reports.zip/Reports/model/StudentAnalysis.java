package smartail.deepgrade.reports.model;

public class StudentAnalysis {
	private int questionNum;
	private String question;
	private String blooms;
	private String rating;
	private int totalRating;
	
	public StudentAnalysis( int questionNum, String question, String blooms, String rating,
			int totalRating) {
		super();
		this.questionNum = questionNum;
		this.question = question;
		this.blooms = blooms;
		this.rating = rating;
		this.totalRating = totalRating;
	}

	
	public StudentAnalysis() {
		super();
	}

	public int getQuestionNum() {
		return questionNum;
	}

	public void setQuestionNum(int questionNum) {
		this.questionNum = questionNum;
	}

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	public String getBlooms() {
		return blooms;
	}

	public void setBlooms(String blooms) {
		this.blooms = blooms;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public int getTotalRating() {
		return totalRating;
	}

	public void setTotalRating(int totalRating) {
		this.totalRating = totalRating;
	}


	@Override
	public String toString() {
		return "StudentAnalysis [questionNum=" + questionNum + ", question=" + question + ", blooms=" + blooms
				+ ", rating=" + rating + ", totalRating=" + totalRating + "]";
	}
	
	
	

}
