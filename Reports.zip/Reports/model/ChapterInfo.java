package smartail.deepgrade.reports.model;

public class ChapterInfo {
	 public String chapterNumber;
	 public String chapterName;
	public ChapterInfo(String chapterNumber, String chapterName) {
		super();
		this.chapterNumber = chapterNumber;
		this.chapterName = chapterName;
	}
	public String getChapterNumber() {
		return chapterNumber;
	}
	public void setChapterNumber(String chapterNumber) {
		this.chapterNumber = chapterNumber;
	}
	public String getChapterName() {
		return chapterName;
	}
	public void setChapterName(String chapterName) {
		this.chapterName = chapterName;
	}
	 
	 
}
