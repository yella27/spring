package smartail.deepgrade.reports.model;

import java.util.List;

public class StudentAnalysisAllQuestion {
	private int questionNum;
	private String question;
	private String blooms;
	private int totalRating;
	private String rating;
	private String contexMatch;
	private String answer;
	private List<String> answerImageLink;
	private  List<SpellCheck> spellCheck; 
	private List<GrammarError> grammarError;
	public List <String> teacherComments;
	public StudentAnalysisAllQuestion() {
		super();
		// TODO Auto-generated constructor stub
	}
	public StudentAnalysisAllQuestion(int questionNum, String question, String blooms, int totalRating, String rating,
			String contexMatch, String answer, List<String> answerImageLink, List<SpellCheck> spellCheck,
			List<GrammarError> grammarError, List<String> teacherComments) {
		super();
		this.questionNum = questionNum;
		this.question = question;
		this.blooms = blooms;
		this.totalRating = totalRating;
		this.rating = rating;
		this.contexMatch = contexMatch;
		this.answer = answer;
		this.answerImageLink = answerImageLink;
		this.spellCheck = spellCheck;
		this.grammarError = grammarError;
		this.teacherComments = teacherComments;
	}
	public int getQuestionNum() {
		return questionNum;
	}
	public void setQuestionNum(int questionNum) {
		this.questionNum = questionNum;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getBlooms() {
		return blooms;
	}
	public void setBlooms(String blooms) {
		this.blooms = blooms;
	}
	public int getTotalRating() {
		return totalRating;
	}
	public void setTotalRating(int totalRating) {
		this.totalRating = totalRating;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public String getContexMatch() {
		return contexMatch;
	}
	public void setContexMatch(String contexMatch) {
		this.contexMatch = contexMatch;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public List<String> getAnswerImageLink() {
		return answerImageLink;
	}
	public void setAnswerImageLink(List<String> answerImageLink) {
		this.answerImageLink = answerImageLink;
	}
	public List<SpellCheck> getSpellCheck() {
		return spellCheck;
	}
	public void setSpellCheck(List<SpellCheck> spellCheck) {
		this.spellCheck = spellCheck;
	}
	public List<GrammarError> getGrammarError() {
		return grammarError;
	}
	public void setGrammarError(List<GrammarError> grammarError) {
		this.grammarError = grammarError;
	}
	public List<String> getTeacherComments() {
		return teacherComments;
	}
	public void setTeacherComments(List<String> teacherComments) {
		this.teacherComments = teacherComments;
	}
	@Override
	public String toString() {
		return "StudentAnalysisAllQuestion [questionNum=" + questionNum + ", question=" + question + ", blooms="
				+ blooms + ", totalRating=" + totalRating + ", rating=" + rating + ", contexMatch=" + contexMatch
				+ ", answer=" + answer + ", answerImageLink=" + answerImageLink + ", spellCheck=" + spellCheck
				+ ", grammarError=" + grammarError + ", teacherComments=" + teacherComments + "]";
	}
	
	
	

}
