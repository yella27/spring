package smartail.deepgrade.reports.model;

import java.util.List;

public class GoodList {
	public int goodcount;
	public List<NameList> namelist;
	
	public List<NameList> getNamelist() {
		return namelist;
	}
	public void setNamelist(List<NameList> namelist) {
		this.namelist = namelist;
	}
	public int getGoodcount() {
		return goodcount;
	}
	public void setGoodcount(int goodcount) {
		this.goodcount = goodcount;
	}
	

}
