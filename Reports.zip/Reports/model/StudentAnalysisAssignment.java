package smartail.deepgrade.reports.model;



public class StudentAnalysisAssignment {
	public PoorList poorlist;
	
	public FairList fairlist;
	
	public AverageList averagelist;
	
	public GoodList goodlist;
	
	public ExcellentList excellentlist;

	public StudentAnalysisAssignment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentAnalysisAssignment(PoorList poorlist, FairList fairlist, AverageList averagelist, GoodList goodlist,
			ExcellentList excellentlist) {
		super();
		this.poorlist = poorlist;
		this.fairlist = fairlist;
		this.averagelist = averagelist;
		this.goodlist = goodlist;
		this.excellentlist = excellentlist;
	}

	public PoorList getPoorlist() {
		return poorlist;
	}

	public void setPoorlist(PoorList poorlist) {
		this.poorlist = poorlist;
	}

	public FairList getFairlist() {
		return fairlist;
	}

	public void setFairlist(FairList fairlist) {
		this.fairlist = fairlist;
	}

	public AverageList getAveragelist() {
		return averagelist;
	}

	public void setAveragelist(AverageList averagelist) {
		this.averagelist = averagelist;
	}

	public GoodList getGoodlist() {
		return goodlist;
	}

	public void setGoodlist(GoodList goodlist) {
		this.goodlist = goodlist;
	}

	public ExcellentList getExcellentlist() {
		return excellentlist;
	}

	public void setExcellentlist(ExcellentList excellentlist) {
		this.excellentlist = excellentlist;
	}

	@Override
	public String toString() {
		return "StudentAnalysisAssignment [poorlist=" + poorlist + ", fairlist=" + fairlist + ", averagelist="
				+ averagelist + ", goodlist=" + goodlist + ", excellentlist=" + excellentlist + "]";
	}
	
	
	
	
	

}
