package smartail.deepgrade.reports.model;

import java.util.List;

public class SingleStudentAnalysis {
	public String studentName; 
	public String studentRollnum;
	public int poor;
	public int average;
	public int good;
	public double overAllPercentage;
	public List<QuestionPercentage> individaulpercentage;
	public List<StudentAnalysis> studentAnalysis;
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentRollnum() {
		return studentRollnum;
	}
	public void setStudentRollnum(String studentRollnum) {
		this.studentRollnum = studentRollnum;
	}
	public int getPoor() {
		return poor;
	}
	public void setPoor(int poor) {
		this.poor = poor;
	}
	public int getAverage() {
		return average;
	}
	public void setAverage(int average) {
		this.average = average;
	}
	public int getGood() {
		return good;
	}
	public void setGood(int good) {
		this.good = good;
	}
	public double getOverAllPercentage() {
		return overAllPercentage;
	}
	public void setOverAllPercentage(double overAllPercentage) {
		this.overAllPercentage = overAllPercentage;
	}
	public List<QuestionPercentage> getIndividaulpercentage() {
		return individaulpercentage;
	}
	public void setIndividaulpercentage(List<QuestionPercentage> individaulpercentage) {
		this.individaulpercentage = individaulpercentage;
	}
	public List<StudentAnalysis> getStudentAnalysis() {
		return studentAnalysis;
	}
	public void setStudentAnalysis(List<StudentAnalysis> studentAnalysis) {
		this.studentAnalysis = studentAnalysis;
	}
	
	

}
