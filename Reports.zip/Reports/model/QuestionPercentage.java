package smartail.deepgrade.reports.model;

public class QuestionPercentage {
	private int questionNum;
	private double percentage;


	public QuestionPercentage() {
		super();
		
	}


	public QuestionPercentage(int questionNum, double percentage) {
		super();
		this.questionNum = questionNum;
		this.percentage = percentage;
	}


	public int getQuestionNum() {
		return questionNum;
	}


	public int setQuestionNum(int questionNum) {
		return this.questionNum = questionNum;
	}


	public double getPercentage() {
		return percentage;
	}


	public double setPercentage(double percentage) {
		return this.percentage = percentage;
	}


	@Override
	public String toString() {
		return "QuestionPercentage [questionNum=" + questionNum + ", percentage=" + percentage + "]";
	}



	
	
	
}
