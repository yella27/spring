package smartail.deepgrade.reports.model;

public class NameList {
	public String studentName;
	public String rating;
	
	public NameList() {
		super();
		// TODO Auto-generated constructor stub
	}
	public NameList(String studentName, String rating) {
		super();
		this.studentName = studentName;
		this.rating = rating;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "NameList [studentName=" + studentName + ", rating=" + rating + "]";
	}
	
	

}
