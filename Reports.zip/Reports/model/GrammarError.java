package smartail.deepgrade.reports.model;

public class GrammarError {
	String message;
	String shortMessage;
	String replacement;
	boolean isEnabled;
	public GrammarError(String message, String shortMessage, String replacement, boolean isEnabled) {
		super();
		this.message = message;
		this.shortMessage = shortMessage;
		this.replacement = replacement;
		this.isEnabled = isEnabled;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getShortMessage() {
		return shortMessage;
	}
	public void setShortMessage(String shortMessage) {
		this.shortMessage = shortMessage;
	}
	public String getReplacement() {
		return replacement;
	}
	public void setReplacement(String replacement) {
		this.replacement = replacement;
	}
	public boolean isEnabled() {
		return isEnabled;
	}
	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
	
	

}
