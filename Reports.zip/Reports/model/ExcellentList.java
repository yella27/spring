package smartail.deepgrade.reports.model;

import java.util.List;

public class ExcellentList {
	public int excellentcount;
	public List<NameList> namelist;
	
	
	public ExcellentList(int excellentcount, List<NameList> namelist) {
		super();
		this.excellentcount = excellentcount;
		this.namelist = namelist;
	}
	public ExcellentList() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getExcellentcount() {
		return excellentcount;
	}
	public void setExcellentcount(int excellentcount) {
		this.excellentcount = excellentcount;
	}
	public List<NameList> getNamelist() {
		return namelist;
	}
	public void setNamelist(List<NameList> namelist) {
		this.namelist = namelist;
	}
	@Override
	public String toString() {
		return "ExcellentList [excellentcount=" + excellentcount + ", namelist=" + namelist + "]";
	}
	

}
