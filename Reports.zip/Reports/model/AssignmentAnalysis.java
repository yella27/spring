package smartail.deepgrade.reports.model;

import java.util.List;

public class AssignmentAnalysis {
	public int poor;
	public int average;
	public int good;
	public MarkStatistics markstatistic;
	public double overAllPercentage;
	public List<QuestionPercentage> individaulpercentage;
	public StudentAnalysisAssignment studentAnalysisOnAssignment;
	
	public AssignmentAnalysis() {
		super();
		// TODO Auto-generated constructor stub
	}


	public AssignmentAnalysis(int poor, int average, int good, MarkStatistics markstatistic, double overAllPercentage,
			List<QuestionPercentage> individaulpercentage,
			StudentAnalysisAssignment studentAnalysisOnAssignment) {
		super();
		this.poor = poor;
		this.average = average;
		this.good = good;
		this.markstatistic = markstatistic;
		this.overAllPercentage = overAllPercentage;
		this.individaulpercentage = individaulpercentage;
		this.studentAnalysisOnAssignment = studentAnalysisOnAssignment;
	}



	public int getPoor() {
		return poor;
	}

	public void setPoor(int poor) {
		this.poor = poor;
	}

	public int getAverage() {
		return average;
	}

	public void setAverage(int average) {
		this.average = average;
	}

	public int getGood() {
		return good;
	}

	public void setGood(int good) {
		this.good = good;
	}

	public MarkStatistics getMarkstatistic() {
		return markstatistic;
	}

	public void setMarkstatistic(MarkStatistics markstatistic) {
		this.markstatistic = markstatistic;
	}

	public double getOverAllPercentage() {
		return overAllPercentage;
	}

	public void setOverAllPercentage(double overAllPercentage) {
		this.overAllPercentage = overAllPercentage;
	}

	public List<QuestionPercentage> getIndividaulpercentage() {
		return individaulpercentage;
	}

	public void setIndividaulpercentage(List<QuestionPercentage> individaulpercentage) {
		this.individaulpercentage = individaulpercentage;
	}

	public StudentAnalysisAssignment getStudentAnalysisOnAssignment() {
		return studentAnalysisOnAssignment;
	}

	public void setStudentAnalysisOnAssignment(StudentAnalysisAssignment studentAnalysisOnAssignment) {
		this.studentAnalysisOnAssignment = studentAnalysisOnAssignment;
	}


	@Override
	public String toString() {
		return "AssignmentAnalysis [poor=" + poor + ", average=" + average + ", good=" + good + ", markstatistic="
				+ markstatistic + ", overAllPercentage=" + overAllPercentage + ", individaulpercentage="
				+ individaulpercentage + ", studentAnalysisOnAssignment=" + studentAnalysisOnAssignment + "]";
	}

	

}
