package smartail.deepgrade.reports.model;

import java.util.List;

public class FairList {
	public int faircount;
	public List<NameList> namelist;
	public FairList() {
		super();
	}
	public int getFaircount() {
		return faircount;
	}
	public void setFaircount(int faircount) {
		this.faircount = faircount;
	}
	public List<NameList> getNamelist() {
		return namelist;
	}
	public void setNamelist(List<NameList> namelist) {
		this.namelist = namelist;
	}
	
	

}
