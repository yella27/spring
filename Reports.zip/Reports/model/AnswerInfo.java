package smartail.deepgrade.reports.model;

import java.util.List;

public class AnswerInfo {
	public String questionId; 
	public String answer; 
	public List<String> answerImageLink;
	public List<String> correctedAnswerImages;
	public List <String> teacherComments;
	public String rating;
	public String answerId;
	public List<SpellCheck> spellCheck; 
	public List<GrammarError> grammarError; 
	public String contextRating; 
	public String contextComment; 
	public String contextMatch; 
	public int manualCorrection;
	public boolean isCorrected; 
	public String extract;
	public String blooms;
	


	public AnswerInfo() {
		super();
		// TODO Auto-generated constructor stub
	}


	public AnswerInfo(String questionId, String answer, List<String> answerImageLink,
			List<String> correctedAnswerImages, List<String> teacherComments, String rating, String answerId,
			List<SpellCheck> spellCheck, List<GrammarError> grammarError, String contextRating, String contextComment,
			String contextMatch, int manualCorrection, boolean isCorrected, String extract, String blooms) {
		super();
		this.questionId = questionId;
		this.answer = answer;
		this.answerImageLink = answerImageLink;
		this.correctedAnswerImages = correctedAnswerImages;
		this.teacherComments = teacherComments;
		this.rating = rating;
		this.answerId = answerId;
		this.spellCheck = spellCheck;
		this.grammarError = grammarError;
		this.contextRating = contextRating;
		this.contextComment = contextComment;
		this.contextMatch = contextMatch;
		this.manualCorrection = manualCorrection;
		this.isCorrected = isCorrected;
		this.extract = extract;
		this.blooms = blooms;
	}


	public String getQuestionId() {
		return questionId;
	}


	public String setQuestionId(String questionId) {
		return this.questionId = questionId;
	}


	public String getAnswer() {
		return answer;
	}


	public void setAnswer(String answer) {
		this.answer = answer;
	}


	public List<String> getAnswerImageLink() {
		return answerImageLink;
	}


	public void setAnswerImageLink(List<String> answerImageLink) {
		this.answerImageLink = answerImageLink;
	}


	public List<String> getCorrectedAnswerImages() {
		return correctedAnswerImages;
	}


	public void setCorrectedAnswerImages(List<String> correctedAnswerImages) {
		this.correctedAnswerImages = correctedAnswerImages;
	}


	public List<String> getTeacherComments() {
		return teacherComments;
	}


	public void setTeacherComments(List<String> teacherComments) {
		this.teacherComments = teacherComments;
	}


	public String getRating() {
		return rating;
	}


	public void setRating(String rating) {
		this.rating = rating;
	}


	public String getAnswerId() {
		return answerId;
	}


	public void setAnswerId(String answerId) {
		this.answerId = answerId;
	}


	public List<SpellCheck> getSpellCheck() {
		return spellCheck;
	}


	public void setSpellCheck(List<SpellCheck> spellCheck) {
		this.spellCheck = spellCheck;
	}


	public List<GrammarError> getGrammarError() {
		return grammarError;
	}


	public void setGrammarError(List<GrammarError> grammarError) {
		this.grammarError = grammarError;
	}


	public String getContextRating() {
		return contextRating;
	}


	public void setContextRating(String contextRating) {
		this.contextRating = contextRating;
	}


	public String getContextComment() {
		return contextComment;
	}


	public void setContextComment(String contextComment) {
		this.contextComment = contextComment;
	}


	public String getContextMatch() {
		return contextMatch;
	}


	public void setContextMatch(String contextMatch) {
		this.contextMatch = contextMatch;
	}


	public int getManualCorrection() {
		return manualCorrection;
	}


	public void setManualCorrection(int manualCorrection) {
		this.manualCorrection = manualCorrection;
	}


	public boolean isCorrected() {
		return isCorrected;
	}


	public void setCorrected(boolean isCorrected) {
		this.isCorrected = isCorrected;
	}


	public String getExtract() {
		return extract;
	}


	public void setExtract(String extract) {
		this.extract = extract;
	}


	public String getBlooms() {
		return blooms;
	}


	public void setBlooms(String blooms) {
		this.blooms = blooms;
	}


	@Override
	public String toString() {
		return "AnswerInfo [questionId=" + questionId +  ", answer=" + answer
				+ ", answerImageLink=" + answerImageLink + ", correctedAnswerImages=" + correctedAnswerImages
				+ ", teacherComments=" + teacherComments + ", rating=" + rating + ", answerId=" + answerId
				+ ", spellCheck=" + spellCheck + ", grammarError=" + grammarError + ", contextRating=" + contextRating
				+ ", contextComment=" + contextComment + ", contextMatch=" + contextMatch + ", manualCorrection="
				+ manualCorrection + ", isCorrected=" + isCorrected + ", extract=" + extract + ", blooms=" + blooms
				+ "]";
	}

	

}
