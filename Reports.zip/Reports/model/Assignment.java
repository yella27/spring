package smartail.deepgrade.reports.model;

import java.util.Date;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Assignment")
public class Assignment {
	@Id
	private ObjectId _id;
	private String type;
	private String teacherId;
	private String assignmentId;
	private String standard;
	private String subject;
	private String title;
	private int classTotalStrength;
	private String assignmentName;
	private int studentTaken;
	private int completedStudentCount;
	private List<String> section;
	private Date startDate;
	private Date submissionDate;
	private List<Date> graceDate;
	private int totalNoOfQuestions;
	private int rating;
	private String assignmentStatus;
	private Boolean archiveFlag;
	private Boolean publishAssignment;
	private String publishCorrection;
	private Date creationTime;
	private Boolean deleteFlag;
	private Boolean aiEnable;
	private Boolean answerUploadEnable;
	private List<Question> question;
	
	
	  
	public Assignment() {
		super();
		
	}
	public Assignment(ObjectId _id, String type, String teacherId, String assignmentId, String standard, String subject,
			String title, int classTotalStrength, String assignmentName, int studentTaken, int completedStudentCount,
			List<String> section, Date startDate, Date submissionDate, List<Date> graceDate, int totalNoOfQuestions,
			int rating, String assignmentStatus, Boolean archiveFlag, Boolean publishAssignment,
			String publishCorrection, Date creationTime, Boolean deleteFlag, Boolean aiEnable,
			Boolean answerUploadEnable, List<Question> question) {
		super();
		this._id = _id;
		this.type = type;
		this.teacherId = teacherId;
		this.assignmentId = assignmentId;
		this.standard = standard;
		this.subject = subject;
		this.title = title;
		this.classTotalStrength = classTotalStrength;
		this.assignmentName = assignmentName;
		this.studentTaken = studentTaken;
		this.completedStudentCount = completedStudentCount;
		this.section = section;
		this.startDate = startDate;
		this.submissionDate = submissionDate;
		this.graceDate = graceDate;
		this.totalNoOfQuestions = totalNoOfQuestions;
		this.rating = rating;
		this.assignmentStatus = assignmentStatus;
		this.archiveFlag = archiveFlag;
		this.publishAssignment = publishAssignment;
		this.publishCorrection = publishCorrection;
		this.creationTime = creationTime;
		this.deleteFlag = deleteFlag;
		this.aiEnable = aiEnable;
		this.answerUploadEnable = answerUploadEnable;
		this.question = question;
	}
	public ObjectId get_id() {
		return _id;
	}
	public void set_id(ObjectId _id) {
		this._id = _id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getTeacherId() {
		return teacherId;
	}
	public void setTeacherId(String teacherId) {
		this.teacherId = teacherId;
	}
	public String getAssignmentId() {
		return assignmentId;
	}
	public void setAssignmentId(String assignmentId) {
		this.assignmentId = assignmentId;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public int getClassTotalStrength() {
		return classTotalStrength;
	}
	public void setClassTotalStrength(int classTotalStrength) {
		this.classTotalStrength = classTotalStrength;
	}
	public String getAssignmentName() {
		return assignmentName;
	}
	public void setAssignmentName(String assignmentName) {
		this.assignmentName = assignmentName;
	}
	public int getStudentTaken() {
		return studentTaken;
	}
	public void setStudentTaken(int studentTaken) {
		this.studentTaken = studentTaken;
	}
	public int getCompletedStudentCount() {
		return completedStudentCount;
	}
	public void setCompletedStudentCount(int completedStudentCount) {
		this.completedStudentCount = completedStudentCount;
	}
	public List<String> getSection() {
		return section;
	}
	public void setSection(List<String> section) {
		this.section = section;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getSubmissionDate() {
		return submissionDate;
	}
	public void setSubmissionDate(Date submissionDate) {
		this.submissionDate = submissionDate;
	}
	public List<Date> getGraceDate() {
		return graceDate;
	}
	public void setGraceDate(List<Date> graceDate) {
		this.graceDate = graceDate;
	}
	public int getTotalNoOfQuestions() {
		return totalNoOfQuestions;
	}
	public void setTotalNoOfQuestions(int totalNoOfQuestions) {
		this.totalNoOfQuestions = totalNoOfQuestions;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getAssignmentStatus() {
		return assignmentStatus;
	}
	public void setAssignmentStatus(String assignmentStatus) {
		this.assignmentStatus = assignmentStatus;
	}
	public Boolean getArchiveFlag() {
		return archiveFlag;
	}
	public void setArchiveFlag(Boolean archiveFlag) {
		this.archiveFlag = archiveFlag;
	}
	public Boolean getPublishAssignment() {
		return publishAssignment;
	}
	public void setPublishAssignment(Boolean publishAssignment) {
		this.publishAssignment = publishAssignment;
	}
	public String getPublishCorrection() {
		return publishCorrection;
	}
	public void setPublishCorrection(String publishCorrection) {
		this.publishCorrection = publishCorrection;
	}
	public Date getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}
	public Boolean getDeleteFlag() {
		return deleteFlag;
	}
	public void setDeleteFlag(Boolean deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	public Boolean getAiEnable() {
		return aiEnable;
	}
	public void setAiEnable(Boolean aiEnable) {
		this.aiEnable = aiEnable;
	}
	public Boolean getAnswerUploadEnable() {
		return answerUploadEnable;
	}
	public void setAnswerUploadEnable(Boolean answerUploadEnable) {
		this.answerUploadEnable = answerUploadEnable;
	}
	public List<Question> getQuestion() {
		return question;
	}
	public void setQuestion(List<Question> question) {
		this.question = question;
	}
	@Override
	public String toString() {
		return "Assignment [_id=" + _id + ", type=" + type + ", teacherId=" + teacherId + ", assignmentId="
				+ assignmentId + ", standard=" + standard + ", subject=" + subject + ", title=" + title
				+ ", classTotalStrength=" + classTotalStrength + ", assignmentName=" + assignmentName
				+ ", studentTaken=" + studentTaken + ", completedStudentCount=" + completedStudentCount + ", section="
				+ section + ", startDate=" + startDate + ", submissionDate=" + submissionDate + ", graceDate="
				+ graceDate + ", totalNoOfQuestions=" + totalNoOfQuestions + ", rating=" + rating
				+ ", assignmentStatus=" + assignmentStatus + ", archiveFlag=" + archiveFlag + ", publishAssignment="
				+ publishAssignment + ", publishCorrection=" + publishCorrection + ", creationTime=" + creationTime
				+ ", deleteFlag=" + deleteFlag + ", aiEnable=" + aiEnable + ", answerUploadEnable=" + answerUploadEnable
				+ ", question=" + question + "]";
	}
	

}
