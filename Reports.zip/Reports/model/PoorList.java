package smartail.deepgrade.reports.model;

import java.util.List;

public class PoorList {
	public int poorcount;
	public List<NameList> namelist;
	
	
	public PoorList() {
		super();
		// TODO Auto-generated constructor stub
	}
	public PoorList(int poorcount, List<NameList> namelist) {
		super();
		this.poorcount = poorcount;
		this.namelist = namelist;
	}
	public int getPoorcount() {
		return poorcount;
	}
	public void setPoorcount(int poorcount) {
		this.poorcount = poorcount;
	}
	public List<NameList> getNamelist() {
		return namelist;
	}
	public void setNamelist(List<NameList> namelist) {
		this.namelist = namelist;
	}
	
	

}
