package smartail.deepgrade.reports.model;

import java.util.List;

public class AverageList {
	public int averagecount;
	public List<NameList> namelist;
	
	
	public int getAveragecount() {
		return averagecount;
	}
	public void setAveragecount(int averagecount) {
		this.averagecount = averagecount;
	}
	public List<NameList> getNamelist() {
		return namelist;
	}
	public void setNamelist(List<NameList> namelist) {
		this.namelist = namelist;
	}
	

}
