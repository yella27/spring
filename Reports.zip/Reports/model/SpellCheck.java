package smartail.deepgrade.reports.model;

import java.util.List;

public class SpellCheck {
	List<String> mistakenWord;
	List<String> correctSpelling;
	boolean isEnabled;
	
	public SpellCheck(List<String> mistakenWord, List<String> correctSpelling, boolean isEnabled) {
		super();
		this.mistakenWord = mistakenWord;
		this.correctSpelling = correctSpelling;
		this.isEnabled = isEnabled;
	}

	public List<String> getMistakenWord() {
		return mistakenWord;
	}

	public void setMistakenWord(List<String> mistakenWord) {
		this.mistakenWord = mistakenWord;
	}

	public List<String> getCorrectSpelling() {
		return correctSpelling;
	}

	public void setCorrectSpelling(List<String> correctSpelling) {
		this.correctSpelling = correctSpelling;
	}

	public boolean isEnabled() {
		return isEnabled;
	}

	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
	
	

}
