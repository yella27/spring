package smartail.deepgrade.reports.AssignmentWorksheet.data;

import java.util.List;

import smartail.deepgrade.reports.AssignmentWorksheet.data.AssignmentsForUploadedData;


public class AssignmentResponse {
	
	private int assignmentCount;
	private List<AssignmentsForUploadedData> assignmentDetails;
	private int worksheetCount;
	private List<WorksheetsForUploadedData> worksheetDetails;
	public AssignmentResponse(int assignmentCount, List<AssignmentsForUploadedData> assignmentDetails, int worksheetCount,
			List<WorksheetsForUploadedData> worksheetDetails) {
		super();
		this.assignmentCount = assignmentCount;
		this.assignmentDetails = assignmentDetails;
		this.worksheetCount = worksheetCount;
		this.worksheetDetails = worksheetDetails;
	}
	public AssignmentResponse(String string) {
		// TODO Auto-generated constructor stub
	}
	public AssignmentResponse() {
		// TODO Auto-generated constructor stub
	}
	public int getAssignmentCount() {
		return assignmentCount;
	}
	public void setAssignmentCount(int assignmentCount) {
		this.assignmentCount = assignmentCount;
	}
	public List<AssignmentsForUploadedData> getAssignmentDetails() {
		return assignmentDetails;
	}
	public void setAssignmentDetails(List<AssignmentsForUploadedData> assignmentDetails) {
		this.assignmentDetails = assignmentDetails;
	}
	public int getWorksheetCount() {
		return worksheetCount;
	}
	public void setWorksheetCount(int worksheetCount) {
		this.worksheetCount = worksheetCount;
	}
	public List<WorksheetsForUploadedData> getWorksheetDetails() {
		return worksheetDetails;
	}
	public void setWorksheetDetails(List<WorksheetsForUploadedData> worksheetDetails) {
		this.worksheetDetails = worksheetDetails;
	}

}
