package smartail.deepgrade.reports.AssignmentWorksheet.data;

import java.util.List;

public class AssignmentsByDate {

	private int assignmentCount;   //total number of assignments for a particular date
	private List<AssignmentDetails> AssignmentDetails;  //list of assignment details
	
	public AssignmentsByDate() {}
	
	public AssignmentsByDate(int assignmentCount, List<smartail.deepgrade.reports.AssignmentWorksheet.data.AssignmentDetails> assignmentDetails) {
		super();
		this.assignmentCount = assignmentCount;
		AssignmentDetails = assignmentDetails;
	}
	public int getAssignmentCount() {
		return assignmentCount;
	}
	public void setAssignmentCount(int assignmentCount) {
		this.assignmentCount = assignmentCount;
	}
	public List<AssignmentDetails> getAssignmentDetails() {
		return AssignmentDetails;
	}
	public void setAssignmentDetails(List<AssignmentDetails> assignmentDetails) {
		AssignmentDetails = assignmentDetails;
	}
	
}
