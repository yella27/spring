package smartail.deepgrade.reports.videoDocument.data;

import java.util.Date;

public class DocumentDetails {

	private String documentId;
	private String subject;
	private String documentTitle;
	private String uploadedBy;
	private Date uploadDate;
	
	public DocumentDetails(String documentId,String subject, String documentTitle, String uploadedBy, Date uploadDate) {
		super();
		this.documentId = documentId;
		this.subject=subject;
		this.documentTitle = documentTitle;
		this.uploadedBy = uploadedBy;
		this.uploadDate = uploadDate;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public DocumentDetails() {
		// TODO Auto-generated constructor stub
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getDocumentTitle() {
		return documentTitle;
	}

	public void setDocumentTitle(String documentTitle) {
		this.documentTitle = documentTitle;
	}

	public String getUploadedBy() {
		return uploadedBy;
	}

	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}

	public Date getUploadDate() {
		return uploadDate;
	}

	public void setUploadDate(Date uploadDate) {
		this.uploadDate = uploadDate;
	}
	
	
}
