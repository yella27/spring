package smartail.deepgrade.reports.Quiz.controller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;



import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import smartail.deepgrade.reports.Quiz.data.gettingdatalist;
import smartail.deepgrade.reports.Quiz.model.quizdetails;


@SpringBootApplication
@RestController
public class Quizcontroller {

	WebClient webclient;

	@PostMapping("/createquiz")
	public Mono<String> addquiz(@RequestBody quizdetails qd) {

		webclient = WebClient.builder().baseUrl("http://localhost:9095")
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();
		return webclient.post().uri(uriBuilder -> uriBuilder.path("/addquiz").build()).body(BodyInserters.fromValue(qd))
				.retrieve().bodyToMono(String.class);

	}

	@GetMapping("/getallquiz")
	public Flux<quizdetails> getallquiz() {

		System.out.println("Hello !");
		webclient = WebClient.builder().baseUrl("http://localhost:9095")
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();
		return webclient.get().uri(uriBuilder -> uriBuilder.path("/findall").build()).retrieve()
				.bodyToFlux(quizdetails.class);

	}

	@GetMapping("/quizreports")
	public Flux<gettingdatalist> getcounts(@RequestParam(name = "standard", defaultValue = "all") String standard,
			@RequestParam(name = "section", defaultValue = "all") String section,
			@RequestParam(name = "subject", defaultValue = "all") String subject,
			@RequestParam(name = "teachername", defaultValue = "all") String teachername,
			@RequestParam(name = "duration", defaultValue = "all") String duration) {

		System.out.println("quiz reports!!" + standard);
		webclient = WebClient.builder().baseUrl("http://localhost:9095")
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();
		// return null;

		try {

			if (standard.equals("all") && section.equals("all") && subject.equals("all") && teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get().uri(uriBuilder -> uriBuilder.path("/reports").build()).retrieve()
							.bodyToFlux(gettingdatalist.class);
				}
			}

			// Filter 1 - Standard ---------------------

			else if (!standard.equals("all") && section.equals("all") && subject.equals("all")
					&& teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}

			// Filter 2 - Section---------------------

			else if (!section.equals("all") && standard.equals("all") && subject.equals("all")
					&& teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("section", section)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("section", section).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}

			}

			// Filter 3 - Subject ----------------------

			else if (!subject.equals("all") && standard.equals("all") && section.equals("all")
					&& teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("subject", subject)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("subject", subject).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}

			}

			// Filter 4 - Teachername ---------------------

			else if (!teachername.equals("all") && standard.equals("all") && section.equals("all")
					&& subject.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("teachername", teachername)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get().uri(
							uriBuilder -> uriBuilder.path("/reports").queryParam("teachername", teachername).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}

			}

			// -------------------- Two Filter --------------------//

			// Filter 1 - Standard And Section ---------------

			else if (!standard.equals("all") && !section.equals("all") && subject.equals("all")
					&& teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}

			}

			// Filter 2 - Standard And Subject -----------------

			else if (!standard.equals("all") && !subject.equals("all") && section.equals("all")
					&& teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("subject", subject).queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("subject", subject).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}

			}

			// Filter 3 - Standard And Teachername ------------------

			else if (!standard.equals("all") && !teachername.equals("all") && section.equals("all")
					&& subject.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("teachername", teachername).queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("teachername", teachername).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}

			}

			// Filter 4 - Section And Subject -------------------

			else if (!subject.equals("all") && !section.equals("all") && standard.equals("all")
					&& teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("section", section)
									.queryParam("subject", subject).queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("section", section)
									.queryParam("subject", subject).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}

			}

			// Filter 5 - Section And Teachername -------------------

			else if (!teachername.equals("all") && !section.equals("all") && standard.equals("all")
					&& subject.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("teachername", teachername)
									.queryParam("section", section).queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("teachername", teachername)
									.queryParam("section", section).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}

			// Filter 6 - Subject And Teachername -----------------

			else if (!subject.equals("all") && !teachername.equals("all") && standard.equals("all")
					&& section.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("subject", subject)
									.queryParam("teachername", teachername).queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("subject", subject)
									.queryParam("teachername", teachername).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}

			// -------------------- Three Filter --------------------//

			// Filters 1 - Standard,Section And Subject

			else if (!standard.equals("all") && !section.equals("all") && !subject.equals("all")
					&& teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).queryParam("subject", subject)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).queryParam("subject", subject).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}

			// Filters 2 - Standard,Section And Teachername -----------------------

			else if (!standard.equals("all") && !section.equals("all") && !teachername.equals("all")
					&& subject.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).queryParam("teachername", teachername)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).queryParam("teachername", teachername).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}

			// Filters 3 - Standard,Subject And Teachername ---------------------

			else if (!standard.equals("all") && !subject.equals("all") && !teachername.equals("all")
					&& section.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("subject", subject).queryParam("teachername", teachername)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("subject", subject).queryParam("teachername", teachername).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}

			// Filters 4 - Section,Subject And Teachername ------------------

			else if (!section.equals("all") && !subject.equals("all") && !teachername.equals("all")
					&& standard.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("section", section)
									.queryParam("subject", subject).queryParam("teachername", teachername)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("section", section)
									.queryParam("subject", subject).queryParam("teachername", teachername).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}

			// -------------------- All Filter --------------------//

			// Filters 1 - Standard,Section, Subject And Teachername
			// ------------------------
			else if (!standard.equals("all") && !section.equals("all") && !subject.equals("all")
					&& !teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).queryParam("subject", subject)
									.queryParam("teachername", teachername).queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).queryParam("subject", subject)
									.queryParam("teachername", teachername).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return null;

	}

	
}


	