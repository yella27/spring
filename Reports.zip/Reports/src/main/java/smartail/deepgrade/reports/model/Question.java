package smartail.deepgrade.reports.model;

import java.util.List;


public class Question {
	
	private String questionId;
	private int questionNum;
	private String question;
	private String imageLink;
	private List<String> answerTextKey;
	private String questionCorrectionStatus;
	private int correctionCompletedCount;
	private int totalManualCorrection;
	private int manualCorrectionCompleted;
	private Boolean aiEnable;
	private List<String> keyWords;
	
	public Question(String questionId, int questionNum, String question, String imageLink, List<String> answerTextKey,
			String questionCorrectionStatus, int correctionCompletedCount, int totalManualCorrection,
			int manualCorrectionCompleted, Boolean aiEnable, List<String> keyWords) {
		super();
		this.questionId = questionId;
		this.questionNum = questionNum;
		this.question = question;
		this.imageLink = imageLink;
		this.answerTextKey = answerTextKey;
		this.questionCorrectionStatus = questionCorrectionStatus;
		this.correctionCompletedCount = correctionCompletedCount;
		this.totalManualCorrection = totalManualCorrection;
		this.manualCorrectionCompleted = manualCorrectionCompleted;
		this.aiEnable = aiEnable;
		this.keyWords = keyWords;
	}
	public String getQuestionId() {
		return questionId;
	}
	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}
	public int getQuestionNum() {
		return questionNum;
	}
	public void setQuestionNum(int questionNum) {
		this.questionNum = questionNum;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getImageLink() {
		return imageLink;
	}
	public void setImageLink(String imageLink) {
		this.imageLink = imageLink;
	}
	public List<String> getAnswerTextKey() {
		return answerTextKey;
	}
	public void setAnswerTextKey(List<String> answerTextKey) {
		this.answerTextKey = answerTextKey;
	}
	public String getQuestionCorrectionStatus() {
		return questionCorrectionStatus;
	}
	public void setQuestionCorrectionStatus(String questionCorrectionStatus) {
		this.questionCorrectionStatus = questionCorrectionStatus;
	}
	public int getCorrectionCompletedCount() {
		return correctionCompletedCount;
	}
	public void setCorrectionCompletedCount(int correctionCompletedCount) {
		this.correctionCompletedCount = correctionCompletedCount;
	}
	public int getTotalManualCorrection() {
		return totalManualCorrection;
	}
	public void setTotalManualCorrection(int totalManualCorrection) {
		this.totalManualCorrection = totalManualCorrection;
	}
	public int getManualCorrectionCompleted() {
		return manualCorrectionCompleted;
	}
	public void setManualCorrectionCompleted(int manualCorrectionCompleted) {
		this.manualCorrectionCompleted = manualCorrectionCompleted;
	}
	public Boolean getAiEnable() {
		return aiEnable;
	}
	public void setAiEnable(Boolean aiEnable) {
		this.aiEnable = aiEnable;
	}
	public List<String> getKeyWords() {
		return keyWords;
	}
	public void setKeyWords(List<String> keyWords) {
		this.keyWords = keyWords;
	}
	@Override
	public String toString() {
		return "Question [questionId=" + questionId + ", questionNum=" + questionNum + ", question=" + question
				+ ", imageLink=" + imageLink + ", answerTextKey=" + answerTextKey + ", questionCorrectionStatus="
				+ questionCorrectionStatus + ", correctionCompletedCount=" + correctionCompletedCount
				+ ", totalManualCorrection=" + totalManualCorrection + ", manualCorrectionCompleted="
				+ manualCorrectionCompleted + ", aiEnable=" + aiEnable + ", keyWords=" + keyWords + "]";
	}

	 

}
