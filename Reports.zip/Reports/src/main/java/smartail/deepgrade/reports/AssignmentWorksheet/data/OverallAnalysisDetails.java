package smartail.deepgrade.reports.AssignmentWorksheet.data;

import java.util.List;

public class OverallAnalysisDetails {
	//private String type;
	//private String questionId;
	private String standard;
	private String subject;
	private String worksheetName;
	private List<String> section;
	private int classTotalStrength;
	private int completedStudentCount;
	public OverallAnalysisDetails( String standard, String subject, String worksheetName, List<String> section,
			int classTotalStrength, int completedStudentCount) {
		super();
	//	this.setType(type);
		//this.questionId = questionId;
		this.standard = standard;
		this.subject = subject;
		this.worksheetName = worksheetName;
		this.section = section;
		//this.assignmentId = assignmentId;
		this.classTotalStrength = classTotalStrength;
		this.completedStudentCount = completedStudentCount;
	}
	public OverallAnalysisDetails() {
		// TODO Auto-generated constructor stub
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getWorksheetName() {
		return worksheetName;
	}
	public void setWorksheetName(String worksheetName) {
		this.worksheetName = worksheetName;
	}
	public List<String> getSection() {
		return section;
	}
	public void setSection(List<String> section) {
		this.section = section;
	}
	public int getClassTotalStrength() {
		return classTotalStrength;
	}
	public void setClassTotalStrength(int classTotalStrength) {
		this.classTotalStrength = classTotalStrength;
	}
	public int getCompletedStudentCount() {
		return completedStudentCount;
	}
	public void setCompletedStudentCount(int completedStudentCount) {
		this.completedStudentCount = completedStudentCount;
	}
	}
