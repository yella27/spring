package smartail.deepgrade.reports.AssignmentWorksheet.model;
import java.util.Date;
import java.util.List;

public class SpellCheck {

	private String mistakenWord;
	private String correctSpelling;
	private boolean isEnabled;
	public SpellCheck(String mistakenWord, String correctSpelling, boolean isEnabled) {
		super();
		this.mistakenWord = mistakenWord;
		this.correctSpelling = correctSpelling;
		this.isEnabled = isEnabled;
	}
	public String getMistakenWord() {
		return mistakenWord;
	}
	public void setMistakenWord(String mistakenWord) {
		this.mistakenWord = mistakenWord;
	}
	public String getCorrectSpelling() {
		return correctSpelling;
	}
	public void setCorrectSpelling(String correctSpelling) {
		this.correctSpelling = correctSpelling;
	}
	public boolean isEnabled() {
		return isEnabled;
	}
	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
}
