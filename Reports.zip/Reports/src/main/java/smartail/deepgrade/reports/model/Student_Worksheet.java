package smartail.deepgrade.reports.model;

import java.util.List;



public class Student_Worksheet {
	
	public String type; 
	public String studentId; 
	public String studentName; 
	public String studentRollnum;
	public String standard; 
	public String section; 
	public String subject; 
	public String assignmentId;
	public String title; 
	public List<AnswerKeyInfo> answer;
	

}
