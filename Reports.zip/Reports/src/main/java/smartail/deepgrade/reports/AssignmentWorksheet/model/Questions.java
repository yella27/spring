package smartail.deepgrade.reports.AssignmentWorksheet.model;

import java.util.List;

import smartail.deepgrade.reports.AssignmentWorksheet.data.questionAnalysis;

public class Questions {
	
	private List<String> question;
	private List<Integer> classTotalStrength;
	private List<Integer> completedStudentCount;
	private List<String> questionId;
	private List<Integer> questionNum;
	public Questions(List<String> question, List<Integer> classTotalStrength, List<Integer> completedStudentCount, List<String> questionId ,List<Integer> questionNum) {
		super();
		this.question = question;
		this.classTotalStrength = classTotalStrength;
		this.completedStudentCount = completedStudentCount;
		this.setQuestionId(questionId);
		this.setQuestionNum(questionNum);

	}
	public Questions() {
		// TODO Auto-generated constructor stub
	}
	public List<String> getQuestion() {
		return question;
	}
	public void setQuestion(List<String> question) {
		this.question = question;
	}
	public List<Integer> getClassTotalStrength() {
		return classTotalStrength;
	}
	public void setClassTotalStrength(List<Integer> classTotalStrength) {
		this.classTotalStrength = classTotalStrength;
	}
	public List<Integer> getCompletedStudentCount() {
		return completedStudentCount;
	}
	public void setCompletedStudentCount(List<Integer> completedStudentCount) {
		this.completedStudentCount = completedStudentCount;
	}
	public void add(questionAnalysis q) {
		// TODO Auto-generated method stub
		
	}
	public List<String> getQuestionId() {
		return questionId;
	}
	public void setQuestionId(List<String> questionId) {
		this.questionId = questionId;
	}
	public List<Integer> getQuestionNum() {
		return questionNum;
	}
	public void setQuestionNum(List<Integer> questionNum) {
		this.questionNum = questionNum;
	}
	


}
