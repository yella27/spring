package smartail.deepgrade.reports.VideoDocuments.models;

import java.util.Date;
import java.util.List;


public class Documents {

	private String _id;
	private String documentId;
	private String documentTitle;
	private String subject;	
	private String standard;
	private List<String> section;
	private String chapter;
	private String type;
	private String description;
	private String documentLink;
	private String uploadedBy;
	private String teacherId;
	private Date uploadDate;
	private String deleteFlag;
	
	public Documents(String _id, String documentId, String documentTitle, String subject, String standard,
			List<String> section, String chapter, String type, String description, String documentLink,
			String uploadedBy, String teacherId, Date uploadDate, String deleteFlag) {
		super();
		this._id = _id;
		this.documentId = documentId;
		this.documentTitle = documentTitle;
		this.subject = subject;
		this.standard = standard;
		this.section = section;
		this.chapter = chapter;
		this.type = type;
		this.description = description;
		this.documentLink = documentLink;
		this.uploadedBy = uploadedBy;
		this.teacherId = teacherId;
		this.uploadDate = uploadDate;
		this.deleteFlag = deleteFlag;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String getDocumentId() {
		return documentId;
	}

	public void setDocumentId(String documentId) {
		this.documentId = documentId;
	}

	public String getDocumentTitle() {
		return documentTitle;
	}

	public void setDocumentTitle(String documentTitle) {
		this.documentTitle = documentTitle;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public List<String> getSection() {
		return section;
	}

	public void setSection(List<String> section) {
		this.section = section;
	}

	public String getChapter() {
		return chapter;
	}

	public void setChapter(String chapter) {
		this.chapter = chapter;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDocumentLink() {
		return documentLink;
	}

	public void setDocumentLink(String documentLink) {
		this.documentLink = documentLink;
	}

	public String getUploadedBy() {
		return uploadedBy;
	}

	public void setUploadedBy(String uploadedBy) {
		this.uploadedBy = uploadedBy;
	}

	public String getTeacherId() {
		return teacherId;
	}

	public void setTeacherId(String teacherId) {
		this.teacherId = teacherId;
	}

	public Date getUploadDate() {
		return uploadDate;
	}

	public void setUploadDate(Date uploadDate) {
		this.uploadDate = uploadDate;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
}
