package smartail.deepgrade.reports.AssignmentWorksheet.data;

import java.util.Date;

public class WorksheetsForUploadedData {
	
	private String teacherId;
	//private String teacherName;
	private String subject; 
	private String worksheetId; 
	private String title; 
	private Date creationTime;
	public WorksheetsForUploadedData(String teacherId, String subject, String worksheetId, String title,
			Date creationTime) {
		super();
		this.teacherId = teacherId;
		this.subject = subject;
		this.worksheetId = worksheetId;
		this.title = title;
		this.creationTime = creationTime;
		
	}
	public WorksheetsForUploadedData() {
		// TODO Auto-generated constructor stub
	}
	public String getTeacherId() {
		return teacherId;
	}
	public void setTeacherId(String teacherId) {
		this.teacherId = teacherId;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getWorksheetId() {
		return worksheetId;
	}
	public void setWorksheetId(String worksheetId) {
		this.worksheetId = worksheetId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Date getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}
	

}
