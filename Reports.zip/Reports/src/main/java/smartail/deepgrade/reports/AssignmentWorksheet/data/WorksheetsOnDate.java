package smartail.deepgrade.reports.AssignmentWorksheet.data;
import java.util.Date;
import java.util.List;


public class WorksheetsOnDate {
	private List<String> worksheetId;
	private List<String> worksheetName;
	private List<Integer> studentTaken;
	private List<Date> creationTime;
    private int WorksheetCount;
	public WorksheetsOnDate(List<String> worksheetId, List<String> worksheetName, List<Integer> studentTaken,
			List<Date> creationTime, int worksheetCount) {
		super();
		this.worksheetId = worksheetId;
		this.worksheetName = worksheetName;
		this.studentTaken = studentTaken;
		this.creationTime = creationTime;
		WorksheetCount = worksheetCount;
	}
	
	public List<String> getWorksheetId() {
		return worksheetId;
	}

	public void setWorksheetId(List<String> worksheetId) {
		this.worksheetId = worksheetId;
	}

	public List<String> getWorksheetName() {
		return worksheetName;
	}

	public void setWorksheetName(List<String> worksheetName) {
		this.worksheetName = worksheetName;
	}

	public List<Integer> getStudentTaken() {
		return studentTaken;
	}

	public void setStudentTaken(List<Integer> studentTaken) {
		this.studentTaken = studentTaken;
	}

	public List<Date> getCreationTime() {
		return creationTime;
	}

	public void setCreationTime(List<Date> creationTime) {
		this.creationTime = creationTime;
	}

	public int getWorksheetCount() {
		return WorksheetCount;
	}

	public void setWorksheetCount(int worksheetCount) {
		WorksheetCount = worksheetCount;
	}

	public WorksheetsOnDate() {
		// TODO Auto-generated constructor stub
	}

}
