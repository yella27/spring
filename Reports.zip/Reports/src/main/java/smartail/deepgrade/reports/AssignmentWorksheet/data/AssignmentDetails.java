package smartail.deepgrade.reports.AssignmentWorksheet.data;

import java.util.Date;

public class AssignmentDetails {

	private String assignmentId;  //fields to be displayed for filtering assignments by date
	private String assignmentName;
	private String standard;
	private String subject;
	private int studentTaken;
	private Date creationTime;
	private int completedStudentCount;
	private Date submissionDate;
	public AssignmentDetails(String assignmentId, String assignmentName, String standard, String subject,
			int studentTaken, Date creationTime, int completedStudentCount, Date submissionDate) {
		super();
		this.assignmentId = assignmentId;
		this.assignmentName = assignmentName;
		this.standard = standard;
		this.subject = subject;
		this.studentTaken = studentTaken;
		this.creationTime = creationTime;
		this.completedStudentCount = completedStudentCount;
		this.submissionDate = submissionDate;
	}
	public AssignmentDetails() {
		// TODO Auto-generated constructor stub
	}
	public String getAssignmentId() {
		return assignmentId;
	}
	public void setAssignmentId(String assignmentId) {
		this.assignmentId = assignmentId;
	}
	public String getAssignmentName() {
		return assignmentName;
	}
	public void setAssignmentName(String assignmentName) {
		this.assignmentName = assignmentName;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public int getStudentTaken() {
		return studentTaken;
	}
	public void setStudentTaken(int studentTaken) {
		this.studentTaken = studentTaken;
	}
	public Date getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}
	public int getCompletedStudentCount() {
		return completedStudentCount;
	}
	public void setCompletedStudentCount(int completedStudentCount) {
		this.completedStudentCount = completedStudentCount;
	}
	public Date getSubmissionDate() {
		return submissionDate;
	}
	public void setSubmissionDate(Date submissionDate) {
		this.submissionDate = submissionDate;
	}


	
}
