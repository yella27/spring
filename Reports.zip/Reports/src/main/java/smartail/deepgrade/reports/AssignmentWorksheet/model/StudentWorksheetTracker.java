package smartail.deepgrade.reports.AssignmentWorksheet.model;
import java.util.Date;
import java.util.List;
public class StudentWorksheetTracker {
	
	public String _id;
	public String type;
	public String studentId;
	public String studentName;
	public String studentRollnum;
	public String standard;
	public String section;
	public String subject;
	public String worksheetId;
	public String title;
	public List<AnswerInfo> answer;
	public String studentWorksheetStatus;
	public String worksheetRating;
	public String archiveFlag;
	public Date startDate;
	public Date submissionDate;
	public String reviewComments;
	public String rating;
	public int totalRating;
	public int noOfCorrectedAnswers;
	public int totalNoOfQuestions;
	public String lastCorrectedQuesId;
	public String correctionFlag;
	public String submissionFlag;
	public List<chapterInfo>  chapterInfo;
	public String bloom;
	
	public StudentWorksheetTracker(String _id, String type, String studentId, String studentName,
			String studentRollnum, String standard, String section, String subject, String worksheetId, String title,
			List<AnswerInfo> answer, String studentWorksheetStatus, String worksheetRating, String archiveFlag,
			Date startDate, Date submissionDate, String reviewComments, String rating, int totalRating,
			int noOfCorrectedAnswers, int totalNoOfQuestions, String lastCorrectedQuesId, String correctionFlag,
			String submissionFlag, List<smartail.deepgrade.reports.AssignmentWorksheet.model.chapterInfo> chapterInfo, String bloom) {
		super();
		this._id = _id;
		this.type = type;
		this.studentId = studentId;
		this.studentName = studentName;
		this.studentRollnum = studentRollnum;
		this.standard = standard;
		this.section = section;
		this.subject = subject;
		this.worksheetId = worksheetId;
		this.title = title;
		this.answer = answer;
		this.studentWorksheetStatus = studentWorksheetStatus;
		this.worksheetRating = worksheetRating;
		this.archiveFlag = archiveFlag;
		this.startDate = startDate;
		this.submissionDate = submissionDate;
		this.reviewComments = reviewComments;
		this.rating = rating;
		this.totalRating = totalRating;
		this.noOfCorrectedAnswers = noOfCorrectedAnswers;
		this.totalNoOfQuestions = totalNoOfQuestions;
		this.lastCorrectedQuesId = lastCorrectedQuesId;
		this.correctionFlag = correctionFlag;
		this.submissionFlag = submissionFlag;
		this.chapterInfo = chapterInfo;
		this.bloom = bloom;

	}
	public StudentWorksheetTracker() {
		// TODO Auto-generated constructor stub
	}
	public String get_id() {
		return _id;
	}
	public void set_id(String _id) {
		this._id = _id;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentRollnum() {
		return studentRollnum;
	}
	public void setStudentRollnum(String studentRollnum) {
		this.studentRollnum = studentRollnum;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getWorksheetId() {
		return worksheetId;
	}
	public void setWorksheetId(String worksheetId) {
		this.worksheetId = worksheetId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public List<AnswerInfo> getAnswer() {
		return answer;
	}
	public void setAnswer(List<AnswerInfo> answer) {
		this.answer = answer;
	}
	public String getStudentWorksheetStatus() {
		return studentWorksheetStatus;
	}
	public void setStudentWorksheetStatus(String studentWorksheetStatus) {
		this.studentWorksheetStatus = studentWorksheetStatus;
	}
	public String getWorksheetRating() {
		return worksheetRating;
	}
	public void setWorksheetRating(String worksheetRating) {
		this.worksheetRating = worksheetRating;
	}
	public String getArchiveFlag() {
		return archiveFlag;
	}
	public void setArchiveFlag(String archiveFlag) {
		this.archiveFlag = archiveFlag;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getSubmissionDate() {
		return submissionDate;
	}
	public void setSubmissionDate(Date submissionDate) {
		this.submissionDate = submissionDate;
	}
	public String getReviewComments() {
		return reviewComments;
	}
	public void setReviewComments(String reviewComments) {
		this.reviewComments = reviewComments;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	public int getTotalRating() {
		return totalRating;
	}
	public void setTotalRating(int totalRating) {
		this.totalRating = totalRating;
	}
	public int getNoOfCorrectedAnswers() {
		return noOfCorrectedAnswers;
	}
	public void setNoOfCorrectedAnswers(int noOfCorrectedAnswers) {
		this.noOfCorrectedAnswers = noOfCorrectedAnswers;
	}
	public int getTotalNoOfQuestions() {
		return totalNoOfQuestions;
	}
	public void setTotalNoOfQuestions(int totalNoOfQuestions) {
		this.totalNoOfQuestions = totalNoOfQuestions;
	}
	public String getLastCorrectedQuesId() {
		return lastCorrectedQuesId;
	}
	public void setLastCorrectedQuesId(String lastCorrectedQuesId) {
		this.lastCorrectedQuesId = lastCorrectedQuesId;
	}
	public String getCorrectionFlag() {
		return correctionFlag;
	}
	public void setCorrectionFlag(String correctionFlag) {
		this.correctionFlag = correctionFlag;
	}
	public String getSubmissionFlag() {
		return submissionFlag;
	}
	public void setSubmissionFlag(String submissionFlag) {
		this.submissionFlag = submissionFlag;
	}
	public List<chapterInfo> getChapterInfo() {
		return chapterInfo;
	}
	public void setChapterInfo(List<chapterInfo> chapterInfo) {
		this.chapterInfo = chapterInfo;
	}
	public String getBloom() {
		return bloom;
	}
	public void setBloom(String bloom) {
		this.bloom = bloom;
	}
}