package smartail.deepgrade.reports.AssignmentWorksheet.data;

import java.util.Date;

public class AssignmentsForUploadedData {

	private String teacherId;
	//private String teacherName;
	private String subject; 
	private String assignmentId; 
	private String title; 
	private Date creationTime;
	public AssignmentsForUploadedData(String teacherId, String subject, String assignmentId, String title,
			Date creationTime) {
		super();
		this.teacherId = teacherId;
		this.subject = subject;
		this.assignmentId = assignmentId;
		this.title =title;
		this.creationTime = creationTime;
	}
	public AssignmentsForUploadedData() {
		// TODO Auto-generated constructor stub
	}
	public String getTeacherId() {
		return teacherId;
	}
	public void setTeacherId(String teacherId) {
		this.teacherId = teacherId;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getAssignmentId() {
		return assignmentId;
	}
	public void setAssignmentId(String assignmentId) {
		this.assignmentId = assignmentId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Date getCreationTime() {
		return creationTime;
	}
	public void setCreationTime(Date creationTime) {
		this.creationTime = creationTime;
	}
}
