package smartail.deepgrade.reports.VisdeoDocument.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;

import reactor.core.publisher.Flux;
import smartail.deepgrade.reports.videoDocument.data.Response;

@RestController
public class VideosController {

	WebClient webclient;

	@GetMapping("/uploadedvideos")
	public Flux<Response> filter(@RequestParam(required = false, defaultValue = "All") String subject,
			@RequestParam(required = false, defaultValue = "All") String standard,
			@RequestParam(required = false, defaultValue = "All") String teacherId,
			@RequestParam(required = false, defaultValue = "All") String section,
			@RequestParam(required = false, defaultValue = "6 months ago") String duration) {

		System.out.println("Hello !");
		webclient = WebClient.builder().baseUrl("http://localhost:9090")
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();

		try {

//-			  //subject 
			System.out.println(subject + " " + standard + " " + teacherId + " " + section);
			if (!subject.equals("All") && standard.equals("All") && teacherId.equals("All") && section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("subject", subject)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// standard
			else if (subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("standard", standard)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// teacher name
			else if (subject.equals("All") && standard.equals("All") && !teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("teacherId", teacherId)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// section
			else if (subject.equals("All") && standard.equals("All") && teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("section", section)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// sub,tname
			else if (!subject.equals("All") && !teacherId.equals("All") && standard.equals("All")
					&& section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("subject", subject)
						.queryParam("teacherId", teacherId).queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}

//-					// sub,sec
			else if (!subject.equals("All") && !section.equals("All") && teacherId.equals("All")
					&& standard.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("subject", subject)
						.queryParam("section", section).queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}

//-					// std,tname
			else if (subject.equals("All") && section.equals("All") && !teacherId.equals("All")
					&& standard.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("standard", standard)
						.queryParam("teacherId", teacherId).queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// sub,std
			else if (!subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("subject", subject)
						.queryParam("standard", standard).queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}

//-					// std,sec
			else if (subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("standard", standard)
						.queryParam("section", section).queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}

//-					// sec,tname
			else if (subject.equals("All") && standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("section", section)
						.queryParam("teacherId", teacherId).queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// std,sub,tname
			else if (!subject.equals("All") && !standard.equals("All") && !teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("standard", standard)
						.queryParam("subject", subject).queryParam("teacherId", teacherId)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// sub,sec,std
			else if (!subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("standard", standard)
						.queryParam("subject", subject).queryParam("section", section)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// sec,std,tname
			else if (subject.equals("All") && !standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("standard", standard)
						.queryParam("section", section).queryParam("teacherId", teacherId)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// tname,sub,sec
			else if (!subject.equals("All") && standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("section", section)
						.queryParam("subject", subject).queryParam("teacherId", teacherId)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// std,sub,tname,sec
			else if (!subject.equals("All") && !standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("standard", standard)
						.queryParam("subject", subject).queryParam("teacherId", teacherId).queryParam("section", section)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			} else {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2")
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;

	}

}
