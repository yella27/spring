package smartail.deepgrade.reports.AssignmentWorksheet.model;
import java.util.Date;
import java.util.List;

public class chapterInfo {
	
	 private String chapterNumber;
	 private String chapterName;
	public chapterInfo(String chapterNumber, String chapterName) {
		super();
		this.chapterNumber = chapterNumber;
		this.chapterName = chapterName;
	}
	public String getChapterNumber() {
		return chapterNumber;
	}
	public void setChapterNumber(String chapterNumber) {
		this.chapterNumber = chapterNumber;
	}
	public String getChapterName() {
		return chapterName;
	}
	public void setChapterName(String chapterName) {
		this.chapterName = chapterName;
	}

}
