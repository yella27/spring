package smartail.deepgrade.reports.AssignmentWorksheet.model;
import java.util.Date;
import java.util.List;

public class GrammarError {

	private String message;
	private String shortMessage;
	private String replacement;
	boolean isEnabled;
	public GrammarError(String message, String shortMessage, String replacement, boolean isEnabled) {
		super();
		this.message = message;
		this.shortMessage = shortMessage;
		this.replacement = replacement;
		this.isEnabled = isEnabled;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getShortMessage() {
		return shortMessage;
	}
	public void setShortMessage(String shortMessage) {
		this.shortMessage = shortMessage;
	}
	public String getReplacement() {
		return replacement;
	}
	public void setReplacement(String replacement) {
		this.replacement = replacement;
	}
	public boolean isEnabled() {
		return isEnabled;
	}
	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}
}
