package smartail.deepgrade.reports.AssignmentWorksheet.model;

import java.util.List;

public class studentSingleQuestionAnalysis {

	private List<AllStudentsSingleQuestionAnalysis> allStudents;

	public studentSingleQuestionAnalysis(List<AllStudentsSingleQuestionAnalysis> allStudents) {
		super();
		this.allStudents = allStudents;
	}

	public List<AllStudentsSingleQuestionAnalysis> getAllStudents() {
		return allStudents;
	}

	public void setAllStudents(List<AllStudentsSingleQuestionAnalysis> allStudents) {
		this.allStudents = allStudents;
	}
}
