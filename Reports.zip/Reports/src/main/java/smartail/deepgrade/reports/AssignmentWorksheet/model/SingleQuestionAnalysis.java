package smartail.deepgrade.reports.AssignmentWorksheet.model;

import java.util.List;

public class SingleQuestionAnalysis {

	private List<String> answerTextKey;
	private String subject;
	private String title;
	private String standard;
	private int classTotalStrength;
	private String worksheetName;
	private int completedStudentCount;
	private String totalMark;
	private String bloom;
	private String StudentName;
	//private List<StudentInfo> StudentInfo;

    public SingleQuestionAnalysis(List<String> answerTextKey, String subject, String title, String standard, int classTotalStrength,
			String worksheetName, int completedStudentCount, String bloom, String StudentName,String totalMark) {
		super();
		this.answerTextKey = answerTextKey;
		this.subject = subject;
		this.title = title;
		this.standard = standard;
		this.classTotalStrength = classTotalStrength;
		this.worksheetName = worksheetName;
		this.completedStudentCount = completedStudentCount;
		this.totalMark = totalMark;
		this.bloom = bloom;
		this.StudentName = StudentName;
	}

	public SingleQuestionAnalysis() {
		// TODO Auto-generated constructor stub
	}

	public List<String> getAnswerTextKey() {
		return answerTextKey;
	}

	public void setAnswerTextKey(List<String> answerTextKey) {
		this.answerTextKey = answerTextKey;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public int getClassTotalStrength() {
		return classTotalStrength;
	}

	public void setClassTotalStrength(int classTotalStrength) {
		this.classTotalStrength = classTotalStrength;
	}

	public String getWorksheetName() {
		return worksheetName;
	}

	public void setWorksheetName(String worksheetName) {
		this.worksheetName = worksheetName;
	}

	public int getCompletedStudentCount() {
		return completedStudentCount;
	}

	public void setCompletedStudentCount(int completedStudentCount) {
		this.completedStudentCount = completedStudentCount;
	}

	//public int getTotalMarks() {
		//return totalMarks;
	//}

	//public void setTotalMarks(int totalMarks) {
		//this.totalMarks = totalMarks;
	//}

	public String getBloom() {
		return bloom;
}

	public void setBloom(String bloom) {
		this.bloom = bloom;
  	}

	

	public String getStudentName() {
		return StudentName;
	}

	public void setStudentName(String studentName) {
		StudentName = studentName;
	}

	

	public String getTotalMark() {
		return totalMark;
	}

	public void setTotalMark(String totalMark) {
		this.totalMark = totalMark;
	}

	//public void setStudentInfo(List<StudentInfo> studentInfo) {
	//	List<StudentInfo> list;StudentInfo("student1",5);
		//StudentInfo = studentInfo;
//	}
}
