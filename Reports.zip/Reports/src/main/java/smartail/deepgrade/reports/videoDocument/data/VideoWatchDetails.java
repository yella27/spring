package smartail.deepgrade.reports.videoDocument.data;


public class VideoWatchDetails {
	
	private String _id;
	private String videoId; 
	private String studentId; 
	private String watchFlag;
	
	public VideoWatchDetails(String _id, String videoId, String studentId, String watchFlag) {
		super();
		this._id = _id;
		this.videoId = videoId;
		this.studentId = studentId;
		this.watchFlag = watchFlag;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String getVideoId() {
		return videoId;
	}

	public void setVideoId(String videoId) {
		this.videoId = videoId;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getWatchFlag() {
		return watchFlag;
	}

	public void setWatchFlag(String watchFlag) {
		this.watchFlag = watchFlag;
	}
	
	
}
