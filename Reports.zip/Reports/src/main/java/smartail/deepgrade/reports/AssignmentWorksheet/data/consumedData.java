package smartail.deepgrade.reports.AssignmentWorksheet.data;

public class consumedData {

}
