package smartail.deepgrade.reports.AssignmentWorksheet.model;

import java.util.List;

public class SingleStudentAllQuestion {
	
	private int questionNum;
	private String question;
	private String bloom;
	private String totalMark;
	private String mark;
	private String studentName;
	private String studentId;
	public SingleStudentAllQuestion(int questionNum,String question, String bloom, String totalMark, String mark,
			String studentName, String studentId) {
		super();
		this.questionNum = questionNum;
		this.question = question;
		this.bloom = bloom;
		this.totalMark = totalMark;
		this.mark = mark;
		this.studentName = studentName;
		this.studentId = studentId;
	}
	public SingleStudentAllQuestion() {
		// TODO Auto-generated constructor stub
	}
	public int getQuestionNum() {
		return questionNum;
	}
	public void setQuestionNum(int questionNum) {
		this.questionNum = questionNum;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public String getBloom() {
		return bloom;
	}
	public void setBloom(String bloom) {
		this.bloom = bloom;
	}
	public String getTotalMark() {
		return totalMark;
	}
	public void setTotalMark(String totalMark) {
		this.totalMark = totalMark;
	}
	public String getMark() {
		return mark;
	}
	public void setMark(String mark) {
		this.mark = mark;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}


}
