package smartail.deepgrade.reports.AssignmentWorksheet.data;

import java.util.List;

public class questionAnalysis {
	
	private String question;
	private int classTotalStrength;
	private int completedStudentCount;
	private String questionId;
	private int questionNum;
	private String blooms;
	private String chapterNumber; 
	private String totalMark; 

	//private List<chapterInfo> chapter;

	
	//averageMarks, TotalMarks
	public questionAnalysis(String question, int classTotalStrength, int completedStudentCount,String questionId,
	int questionNum, String blooms , String chapterNumber,String totalMark ) {
		super();
		this.question = question;
		this.classTotalStrength = classTotalStrength;
		this.completedStudentCount = completedStudentCount;
		this.questionId =questionId;
		this.questionNum = questionNum;
		this.blooms = blooms;
		this.chapterNumber = chapterNumber;
		this.totalMark = totalMark;
		

	}
	public questionAnalysis() {
		// TODO Auto-generated constructor stub
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public int getClassTotalStrength() {
		return classTotalStrength;
	}
	public void setClassTotalStrength(int classTotalStrength) {
		this.classTotalStrength = classTotalStrength;
	}
	public int getCompletedStudentCount() {
		return completedStudentCount;
	}
	public void setCompletedStudentCount(int completedStudentCount) {
		this.completedStudentCount = completedStudentCount;
	}
	public String getQuestionId() {
		return questionId;
	}
	public void setQuestionId(String questionId) {
		this.questionId = questionId;
	}
	public int getQuestionNum() {
		return questionNum;
	}
	public void setQuestionNum(int questionNum) {
		this.questionNum = questionNum;
	}
	public String getBlooms() {
		return blooms;
	}
	public void setBlooms(String blooms) {
		this.blooms = blooms;
	}
	public String getChapterNumber() {
		return chapterNumber;
	}
	public void setChapterNumber(String chapterNumber) {
		this.chapterNumber = chapterNumber;
	}
	public String getTotalMark() {
		return totalMark;
	}
	public void setTotalMark(String totalMark) {
		this.totalMark = totalMark;
	}
	
//	public List<chapterInfo> getChapter() {
	//	return chapter;
	//}
	//public void setChapter(List<chapterInfo> chapter) {
		//this.chapter = chapter;
	//}
	
}
