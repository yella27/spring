package smartail.deepgrade.reports.AssignmentWorksheet.data;

import java.util.Date;

public class uploadDate {

	private String assignmentName;
	private Date startDate;
	private String assignmentStatus;
	private String assignmentId;
	private String title;

	
	public uploadDate(String assignmentName, Date startDate, String assignmentStatus,String assignmentId,String title ) {
		super();
		this.assignmentName = assignmentName;
		this.startDate = startDate;
		this.assignmentStatus = assignmentStatus;
		this.assignmentId = assignmentId;
		this.title = title;
	}
	public uploadDate() {
		// TODO Auto-generated constructor stub
	}
	public String getAssignmentName() {
		return assignmentName;
	}
	public void setAssignmentName(String assignmentName) {
		this.assignmentName = assignmentName;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public String getAssignmentStatus() {
		return assignmentStatus;
	}
	public void setAssignmentStatus(String assignmentStatus) {
		this.assignmentStatus = assignmentStatus;
	}
	public String getAssignmentId() {
		return assignmentId;
	}
	public void setAssignmentId(String assignmentId) {
		this.assignmentId = assignmentId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}

}
