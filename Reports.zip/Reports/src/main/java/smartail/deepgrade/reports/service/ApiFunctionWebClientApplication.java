package smartail.deepgrade.reports.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;



import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;
import smartail.deepgrade.reports.AssignmentWorksheet.data.AssignmentResponse;
import smartail.deepgrade.reports.Quiz.data.gettingdatalist;
import smartail.deepgrade.reports.Quiz.model.quizdetails;
import smartail.deepgrade.reports.model.SingleStudentAnalysis;
import smartail.deepgrade.reports.videoDocument.data.Response;


@SpringBootApplication
@RestController
public class ApiFunctionWebClientApplication {

	WebClient webclient;

	@PostMapping("/createquiz")
	public Mono<String> addquiz(@RequestBody quizdetails qd) {

		webclient = WebClient.builder().baseUrl("http://localhost:9095")
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();
		return webclient.post().uri(uriBuilder -> uriBuilder.path("/addquiz").build()).body(BodyInserters.fromValue(qd))
				.retrieve().bodyToMono(String.class);

	}

	@GetMapping("/getallquiz")
	public Flux<quizdetails> getallquiz() {

		System.out.println("Hello !");
		webclient = WebClient.builder().baseUrl("http://localhost:9095")
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();
		return webclient.get().uri(uriBuilder -> uriBuilder.path("/findall").build()).retrieve()
				.bodyToFlux(quizdetails.class);

	}

	@GetMapping("/quizreports")
	public Flux<gettingdatalist> getcounts(@RequestParam(name = "standard", defaultValue = "all") String standard,
			@RequestParam(name = "section", defaultValue = "all") String section,
			@RequestParam(name = "subject", defaultValue = "all") String subject,
			@RequestParam(name = "teachername", defaultValue = "all") String teachername,
			@RequestParam(name = "duration", defaultValue = "all") String duration) {

		System.out.println("quiz reports!!" + standard);
		webclient = WebClient.builder().baseUrl("http://localhost:9095")
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();
		// return null;

		try {

			if (standard.equals("all") && section.equals("all") && subject.equals("all") && teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get().uri(uriBuilder -> uriBuilder.path("/reports").build()).retrieve()
							.bodyToFlux(gettingdatalist.class);
				}
			}

			// Filter 1 - Standard ---------------------

			else if (!standard.equals("all") && section.equals("all") && subject.equals("all")
					&& teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}

			// Filter 2 - Section---------------------

			else if (!section.equals("all") && standard.equals("all") && subject.equals("all")
					&& teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("section", section)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("section", section).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}

			}

			// Filter 3 - Subject ----------------------

			else if (!subject.equals("all") && standard.equals("all") && section.equals("all")
					&& teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("subject", subject)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("subject", subject).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}

			}

			// Filter 4 - Teachername ---------------------

			else if (!teachername.equals("all") && standard.equals("all") && section.equals("all")
					&& subject.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("teachername", teachername)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get().uri(
							uriBuilder -> uriBuilder.path("/reports").queryParam("teachername", teachername).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}

			}

			// -------------------- Two Filter --------------------//

			// Filter 1 - Standard And Section ---------------

			else if (!standard.equals("all") && !section.equals("all") && subject.equals("all")
					&& teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}

			}

			// Filter 2 - Standard And Subject -----------------

			else if (!standard.equals("all") && !subject.equals("all") && section.equals("all")
					&& teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("subject", subject).queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("subject", subject).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}

			}

			// Filter 3 - Standard And Teachername ------------------

			else if (!standard.equals("all") && !teachername.equals("all") && section.equals("all")
					&& subject.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("teachername", teachername).queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("teachername", teachername).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}

			}

			// Filter 4 - Section And Subject -------------------

			else if (!subject.equals("all") && !section.equals("all") && standard.equals("all")
					&& teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("section", section)
									.queryParam("subject", subject).queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("section", section)
									.queryParam("subject", subject).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}

			}

			// Filter 5 - Section And Teachername -------------------

			else if (!teachername.equals("all") && !section.equals("all") && standard.equals("all")
					&& subject.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("teachername", teachername)
									.queryParam("section", section).queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("teachername", teachername)
									.queryParam("section", section).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}

			// Filter 6 - Subject And Teachername -----------------

			else if (!subject.equals("all") && !teachername.equals("all") && standard.equals("all")
					&& section.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("subject", subject)
									.queryParam("teachername", teachername).queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("subject", subject)
									.queryParam("teachername", teachername).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}

			// -------------------- Three Filter --------------------//

			// Filters 1 - Standard,Section And Subject

			else if (!standard.equals("all") && !section.equals("all") && !subject.equals("all")
					&& teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).queryParam("subject", subject)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).queryParam("subject", subject).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}

			// Filters 2 - Standard,Section And Teachername -----------------------

			else if (!standard.equals("all") && !section.equals("all") && !teachername.equals("all")
					&& subject.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).queryParam("teachername", teachername)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).queryParam("teachername", teachername).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}

			// Filters 3 - Standard,Subject And Teachername ---------------------

			else if (!standard.equals("all") && !subject.equals("all") && !teachername.equals("all")
					&& section.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("subject", subject).queryParam("teachername", teachername)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("subject", subject).queryParam("teachername", teachername).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}

			// Filters 4 - Section,Subject And Teachername ------------------

			else if (!section.equals("all") && !subject.equals("all") && !teachername.equals("all")
					&& standard.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("section", section)
									.queryParam("subject", subject).queryParam("teachername", teachername)
									.queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("section", section)
									.queryParam("subject", subject).queryParam("teachername", teachername).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}

			// -------------------- All Filter --------------------//

			// Filters 1 - Standard,Section, Subject And Teachername
			// ------------------------
			else if (!standard.equals("all") && !section.equals("all") && !subject.equals("all")
					&& !teachername.equals("all")) {

				if (!duration.equals("all")) {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).queryParam("subject", subject)
									.queryParam("teachername", teachername).queryParam("duration", duration).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				} else {
					return webclient.get()
							.uri(uriBuilder -> uriBuilder.path("/reports").queryParam("standard", standard)
									.queryParam("section", section).queryParam("subject", subject)
									.queryParam("teachername", teachername).build())
							.retrieve().bodyToFlux(gettingdatalist.class);
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		
		return null;

	}
//---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------7
	@GetMapping("/uploadedvideos")
	public Flux<Response> filter(@RequestParam(required = false, defaultValue = "All") String subject,
			@RequestParam(required = false, defaultValue = "All") String standard,
			@RequestParam(required = false, defaultValue = "All") String teacherId,
			@RequestParam(required = false, defaultValue = "All") String section,
			@RequestParam(required = false, defaultValue = "6 months ago") String duration) {

		System.out.println("Hello !");
		webclient = WebClient.builder().baseUrl("http://localhost:9090")
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();

		try {

//-			  //subject 
			System.out.println(subject + " " + standard + " " + teacherId + " " + section);
			if (!subject.equals("All") && standard.equals("All") && teacherId.equals("All") && section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("subject", subject)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// standard
			else if (subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("standard", standard)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// teacher name
			else if (subject.equals("All") && standard.equals("All") && !teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("teacherId", teacherId)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// section
			else if (subject.equals("All") && standard.equals("All") && teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("section", section)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// sub,tname
			else if (!subject.equals("All") && !teacherId.equals("All") && standard.equals("All")
					&& section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("subject", subject)
						.queryParam("teacherId", teacherId).queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}

//-					// sub,sec
			else if (!subject.equals("All") && !section.equals("All") && teacherId.equals("All")
					&& standard.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("subject", subject)
						.queryParam("section", section).queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}

//-					// std,tname
			else if (subject.equals("All") && section.equals("All") && !teacherId.equals("All")
					&& standard.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("standard", standard)
						.queryParam("teacherId", teacherId).queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// sub,std
			else if (!subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("subject", subject)
						.queryParam("standard", standard).queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}

//-					// std,sec
			else if (subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("standard", standard)
						.queryParam("section", section).queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}

//-					// sec,tname
			else if (subject.equals("All") && standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("section", section)
						.queryParam("teacherId", teacherId).queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// std,sub,tname
			else if (!subject.equals("All") && !standard.equals("All") && !teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("standard", standard)
						.queryParam("subject", subject).queryParam("teacherId", teacherId)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// sub,sec,std
			else if (!subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("standard", standard)
						.queryParam("subject", subject).queryParam("section", section)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// sec,std,tname
			else if (subject.equals("All") && !standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("standard", standard)
						.queryParam("section", section).queryParam("teacherId", teacherId)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// tname,sub,sec
			else if (!subject.equals("All") && standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("section", section)
						.queryParam("subject", subject).queryParam("teacherId", teacherId)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
//-					// std,sub,tname,sec
			else if (!subject.equals("All") && !standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2").queryParam("standard", standard)
						.queryParam("subject", subject).queryParam("teacherId", teacherId).queryParam("section", section)
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			} else {
				return webclient.get().uri(uriBuilder -> uriBuilder.path("/filters2")
						.queryParam("duration", duration)
						.build()).retrieve()
						.bodyToFlux(Response.class);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;

	}

//--------------------------------------------------------------------------------


	@GetMapping("/uploadedworksheet")
	public Flux<AssignmentResponse> uploaddata(@RequestParam(required = false, defaultValue = "All") String subject,
			@RequestParam(required = false, defaultValue = "All") String standard,
			@RequestParam(required = false, defaultValue = "All") String teacherId,
			@RequestParam(required = false, defaultValue = "All") String section,
			@RequestParam(required = false, defaultValue = "6 months ago") String duration) {

		System.out.println("Hello !");
		webclient = WebClient.builder().baseUrl("http://localhost:8080")
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();

		try {

			System.out.println(subject + " " + standard + " " + teacherId + " " + section);
			if (!subject.equals("All") && standard.equals("All") && teacherId.equals("All") && section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("subject", subject)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			} else if (subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("standard", standard)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// teacher name
			else if (subject.equals("All") && standard.equals("All") && !teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters")
								.queryParam("teacherId", teacherId).queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// section
			else if (subject.equals("All") && standard.equals("All") && teacherId.equals("All")
					&& !section.equals("All")) {

				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("section", section)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// sub,tname
			else if (!subject.equals("All") && !teacherId.equals("All") && standard.equals("All")
					&& section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("subject", subject)
								.queryParam("teacherId", teacherId).queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}

//-					// sub,sec
			else if (!subject.equals("All") && !section.equals("All") && teacherId.equals("All")
					&& standard.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("subject", subject)
								.queryParam("section", section).queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}

//-					// std,tname
			else if (subject.equals("All") && section.equals("All") && !teacherId.equals("All")
					&& !standard.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("standard", standard)
								.queryParam("teacherId", teacherId).queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// sub,std
			else if (!subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("subject", subject)
								.queryParam("standard", standard).queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}

//-					// std,sec
			else if (subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("standard", standard)
								.queryParam("section", section).queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}

//-					// sec,tname
			else if (subject.equals("All") && standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters")
								.queryParam("teacherId", teacherId).queryParam("section", section)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// std,sub,tname
			else if (!subject.equals("All") && !standard.equals("All") && !teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("standard", standard)
								.queryParam("subject", subject).queryParam("teacherId", teacherId)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// sub,sec,std
			else if (!subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("standard", standard)
								.queryParam("subject", subject).queryParam("section", section)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// sec,std,tname
			else if (subject.equals("All") && !standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("standard", standard)
								.queryParam("section", section).queryParam("teacherId", teacherId)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// tname,sub,sec
			else if (!subject.equals("All") && standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("section", section)
								.queryParam("subject", subject).queryParam("teacherId", teacherId)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// std,sub,tname,sec
			else if (!subject.equals("All") && !standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("standard", standard)
								.queryParam("subject", subject).queryParam("teacherId", teacherId)
								.queryParam("section", section).queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			} else {
				return webclient
						.get().uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters")
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;

	}
	//////////////////////////////////////////////////////////////////////////////////////////
	@GetMapping("/studentAnalysisWeb")
	public Flux<SingleStudentAnalysis> analysis(@RequestParam String standard, String assignmentId,String studentId) {
		webclient = WebClient.builder().baseUrl("http://localhost:2020")
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();
		return webclient.get()
				.uri(uriBuilder -> uriBuilder.path("/studentAnalysis").queryParam("standard", standard)
						.queryParam("assignmentId", assignmentId).queryParam("studentId", studentId).build())
				.retrieve().bodyToFlux(SingleStudentAnalysis.class);

	}
	
	@GetMapping("/studentAnalysisDetailsWeb")
	public Flux<SingleStudentAnalysis> analysisDetail(@RequestParam String standard, String assignmentId,String studentId) {
		webclient = WebClient.builder().baseUrl("http://localhost:2020")
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();
		return webclient.get()
				.uri(uriBuilder -> uriBuilder.path("/studentAnalysisDetails").queryParam("standard", standard)
						.queryParam("assignmentId", assignmentId).queryParam("studentId", studentId).build())
				.retrieve().bodyToFlux(SingleStudentAnalysis.class);

	}
	
	@GetMapping("/AssignmentAnalysisWeb")
	public Flux<SingleStudentAnalysis> AssignmentAnalysis(@RequestParam String assignmentId,String standard,String section) {
		webclient = WebClient.builder().baseUrl("http://localhost:2020")
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();
		return webclient.get()
				.uri(uriBuilder -> uriBuilder.path("/AssignmentAnalysis").queryParam("standard", standard)
						.queryParam("assignmentId", assignmentId).queryParam("section", section).build())
				.retrieve().bodyToFlux(SingleStudentAnalysis.class);

	}
	
	
	






//--------------------------------------------------------------------------------------------
	public static void main(String[] args) {
		SpringApplication.run(ApiFunctionWebClientApplication.class, args);
	}

}
