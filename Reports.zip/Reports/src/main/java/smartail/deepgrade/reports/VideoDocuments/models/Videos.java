package smartail.deepgrade.reports.VideoDocuments.models;

import java.util.Date;


public class Videos {

	//filters: std,teacherName,subject,date
	private String _id;
	private String videoId;
	private String standard;
	private String subject;	
	private String chapterName;
	private String chapterNumber;
	private String topic;
	private String description;
	private Date uploadDate;
	private String uploadTeacherId;
	private String uploadTeacherName;
	private String s3Link;
	private String thumbnailLink;
	private String compressionFlag;
	private String originalUrl;
	private String publish;
	
	
	public Videos(String _id, String videoId, String standard, String subject, String chapterName,
			String chapterNumber, String topic, String description, Date uploadDate, String uploadTeacherId,
			String uploadTeacherName, String s3Link, String thumbnailLink, String compressionFlag, String originalUrl,
			String publish) {
		super();
		this._id = _id;
		this.videoId = videoId;
		this.standard = standard;
		this.subject = subject;
		this.chapterName = chapterName;
		this.chapterNumber = chapterNumber;
		this.topic = topic;
		this.description = description;
		this.uploadDate = uploadDate;
		this.uploadTeacherId = uploadTeacherId;
		this.uploadTeacherName = uploadTeacherName;
		this.s3Link = s3Link;
		this.thumbnailLink = thumbnailLink;
		this.compressionFlag = compressionFlag;
		this.originalUrl = originalUrl;
		this.publish = publish;
	}


	public String get_id() {
		return _id;
	}


	public void set_id(String _id) {
		this._id = _id;
	}


	public String getVideoId() {
		return videoId;
	}


	public void setVideoId(String videoId) {
		this.videoId = videoId;
	}


	public String getStandard() {
		return standard;
	}


	public void setStandard(String standard) {
		this.standard = standard;
	}


	public String getSubject() {
		return subject;
	}


	public void setSubject(String subject) {
		this.subject = subject;
	}


	public String getChapterName() {
		return chapterName;
	}


	public void setChapterName(String chapterName) {
		this.chapterName = chapterName;
	}


	public String getChapterNumber() {
		return chapterNumber;
	}


	public void setChapterNumber(String chapterNumber) {
		this.chapterNumber = chapterNumber;
	}


	public String getTopic() {
		return topic;
	}


	public void setTopic(String topic) {
		this.topic = topic;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public Date getUploadDate() {
		return uploadDate;
	}


	public void setUploadDate(Date uploadDate) {
		this.uploadDate = uploadDate;
	}


	public String getUploadTeacherId() {
		return uploadTeacherId;
	}


	public void setUploadTeacherId(String uploadTeacherId) {
		this.uploadTeacherId = uploadTeacherId;
	}


	public String getUploadTeacherName() {
		return uploadTeacherName;
	}


	public void setUploadTeacherName(String uploadTeacherName) {
		this.uploadTeacherName = uploadTeacherName;
	}


	public String getS3Link() {
		return s3Link;
	}


	public void setS3Link(String s3Link) {
		this.s3Link = s3Link;
	}


	public String getThumbnailLink() {
		return thumbnailLink;
	}


	public void setThumbnailLink(String thumbnailLink) {
		this.thumbnailLink = thumbnailLink;
	}


	public String getCompressionFlag() {
		return compressionFlag;
	}


	public void setCompressionFlag(String compressionFlag) {
		this.compressionFlag = compressionFlag;
	}


	public String getOriginalUrl() {
		return originalUrl;
	}


	public void setOriginalUrl(String originalUrl) {
		this.originalUrl = originalUrl;
	}


	public String getPublish() {
		return publish;
	}


	public void setPublish(String publish) {
		this.publish = publish;
	}
	
	
	
}