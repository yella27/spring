package smartail.deepgrade.reports.videoDocument.data;

import java.util.Date;

public class VideoDetails {
	
	private String uploadTeacherId;
	private String uploadTeacherName;
	private String subject; 
	private String videoId; 
	private String topic; 
	private Date date;
	
	public VideoDetails() {}
	
	public VideoDetails(String uploadTeacherId,String subject, String uploadTeacherName, String videoId, String topic, Date date) {
		super();
		this.uploadTeacherId = uploadTeacherId;
		this.subject=subject;
		this.uploadTeacherName = uploadTeacherName;
		this.videoId = videoId;
		this.topic = topic;
		this.date = date;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getUploadTeacherId() {
		return uploadTeacherId;
	}

	public void setUploadTeacherId(String uploadTeacherId) {
		this.uploadTeacherId = uploadTeacherId;
	}

	public String getUploadTeacherName() {
		return uploadTeacherName;
	}

	public void setUploadTeacherName(String uploadTeacherName) {
		this.uploadTeacherName = uploadTeacherName;
	}

	public String getVideoId() {
		return videoId;
	}

	public void setVideoId(String videoId) {
		this.videoId = videoId;
	}

	public String getTopic() {
		return topic;
	}

	public void setTopic(String topic) {
		this.topic = topic;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
	
	
}
