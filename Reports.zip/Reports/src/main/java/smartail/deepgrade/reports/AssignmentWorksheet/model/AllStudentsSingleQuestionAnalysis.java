package smartail.deepgrade.reports.AssignmentWorksheet.model;

import java.util.Date;
import java.util.List;

public class AllStudentsSingleQuestionAnalysis {
	
	private String studentName;
	private String answer;
	private String contextMatch;
	private String bloom;
    private String question;
    private List<String> answerImageLink;
    private List<SpellCheck> spellcheck;
    private List<GrammarError> grammarerror;

	public AllStudentsSingleQuestionAnalysis(String studentName, String answer, String contextMatch,
			String bloom, String question, List<String> answerImageLink , List<SpellCheck> spellcheck , List<GrammarError> grammarerror) {
		super();
		this.studentName = studentName;
		this.answer = answer;
		this.contextMatch = contextMatch;
		this.bloom = bloom;
		this.question = question;
		this.answerImageLink = answerImageLink;
		this.spellcheck = spellcheck;
		this.grammarerror = grammarerror;

	}
	public AllStudentsSingleQuestionAnalysis() {
		// TODO Auto-generated constructor stub
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getContextMatch() {
		return contextMatch;
	}
	public void setContextMatch(String contextMatch) {
		this.contextMatch = contextMatch;
	}
	public String getBloom() {
		return bloom;
	}
	public void setBloom(String bloom) {
		this.bloom = bloom;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	public List<String> getAnswerImageLink() {
		return answerImageLink;
	}
	public void setAnswerImageLink(List<String> answerImageLink) {
		this.answerImageLink = answerImageLink;
	}
	public List<SpellCheck> getSpellcheck() {
		return spellcheck;
	}
	public void setSpellcheck(List<SpellCheck> spellcheck) {
		this.spellcheck = spellcheck;
	}
	public List<GrammarError> getGrammarerror() {
		return grammarerror;
	}
	public void setGrammarerror(List<GrammarError> grammarerror) {
		this.grammarerror = grammarerror;
	}
    

}
