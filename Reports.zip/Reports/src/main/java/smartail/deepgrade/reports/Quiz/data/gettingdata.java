package smartail.deepgrade.reports.Quiz.data;

import java.util.Date;

public class gettingdata {
	
	private String standard;
	private String section;
	private String title;
	private String subject;
	private String teacherName;
	private Date date;
	
	public gettingdata() {}
	
	public gettingdata(String standard, String section, String teacherName, String subject, String title, Date date) {
		super();
		this.standard = standard;
		this.section = section;
		this.teacherName = teacherName;
		this.subject = subject;
		this.title = title;
		this.date = date;
	}
	
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}
}
