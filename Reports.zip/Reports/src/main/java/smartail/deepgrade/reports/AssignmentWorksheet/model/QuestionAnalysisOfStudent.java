package smartail.deepgrade.reports.AssignmentWorksheet.model;

import java.util.List;

public class QuestionAnalysisOfStudent {

   
	private String answer;
	private String studentName;
	private String studentId;
    private String subject;
    private List<String> answerTextKey;
	private String title;
	private String bloom;
	private String contextMatch;
    private List<String> correctedAnswerImages;
    private List<SpellCheck> spellCheck;
	private List<GrammarError> grammarError;
		//totalmark
		//markObtained
	public QuestionAnalysisOfStudent(String answer, String studentName, String studentId,String subject, List<String> answerTextKey,
			String title, String bloom, String contextMatch, List<String> correctedAnswerImages,
			List<SpellCheck> spellCheck, List<GrammarError> grammarError) {
		super();
		this.answer = answer;
		this.studentName = studentName;
		this.studentId = studentId;

		this.subject = subject;
		this.answerTextKey = answerTextKey;
		this.title = title;
		this.bloom = bloom;
		this.contextMatch = contextMatch;
		this.correctedAnswerImages = correctedAnswerImages;
		this.spellCheck = spellCheck;
		this.grammarError = grammarError;
		//this.mistakenWord = mistakenWord;
	}
	public QuestionAnalysisOfStudent() {
		// TODO Auto-generated constructor stub
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public List<String> getAnswerTextKey() {
		return answerTextKey;
	}
	public void setAnswerTextKey(List<String> answerTextKey) {
		this.answerTextKey = answerTextKey;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getBloom() {
		return bloom;
	}
	public void setBloom(String bloom) {
		this.bloom = bloom;
	}
	public String getContextMatch() {
		return contextMatch;
	}
	public void setContextMatch(String contextMatch) {
		this.contextMatch = contextMatch;
	}
	public List<String> getCorrectedAnswerImages() {
		return correctedAnswerImages;
	}
	public void setCorrectedAnswerImages(List<String> correctedAnswerImages) {
		this.correctedAnswerImages = correctedAnswerImages;
	}
	public List<SpellCheck> getSpellCheck() {
		return spellCheck;
	}
	public void setSpellCheck(List<SpellCheck> spellCheck) {
		this.spellCheck = spellCheck;
	}
	public List<GrammarError> getGrammarError() {
		return grammarError;
	}
	public void setGrammarError(List<GrammarError> grammarError) {
		this.grammarError = grammarError;
	}
	public String getStudentId() {
		return studentId;
	}
	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}	
}
