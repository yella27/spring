package smartail.deepgrade.reports.Quiz.model;

import java.util.Date;



public class quizdetails {
	
	public String quizId;
	public String teacherid;
	public String teachername;
	public String videoId;
	public String standard;
	public String subject;
	public String section;
	public String title;
	public String chooseCount;
	public String fillUpCount;
	public String trueOrFalseCount;
	public String oneWordCount;
	public String maximumQuestion;
	public String quizTime;
	public String quizStartTime;
	public String quizEndTime;
	public String totalMarks;
	public String totalStudents;
	public String noOfStudentsTaken;
	private Date creationdate;
	public String startDate;
	public String submissionDate;
	public String graceDate;
	public String quizType;
	public String deleteQuiz;
	
	
	
	public quizdetails() {}
	
	public quizdetails(String quizId, String teacherid,String teachername, String videoId, String standard,
			String subject, String section, String title, String chooseCount, String fillUpCount,
			String trueOrFalseCount, String oneWordCount, String maximumQuestion, String quizTime, String quizStartTime,
			String quizEndTime, String totalMarks, String totalStudents, String noOfStudentsTaken, Date creationdate, String startDate,
			String submissionDate, String graceDate, String quizType, String deleteQuiz) {
		super();
		this.quizId = quizId;
		this.teacherid = teacherid;
		this.teachername = teachername;
		this.videoId = videoId;
		this.standard = standard;
		this.subject = subject;
		this.section = section;
		this.title = title;
		this.chooseCount = chooseCount;
		this.fillUpCount = fillUpCount;
		this.trueOrFalseCount = trueOrFalseCount;
		this.oneWordCount = oneWordCount;
		this.maximumQuestion = maximumQuestion;
		this.quizTime = quizTime;
		this.quizStartTime = quizStartTime;
		this.quizEndTime = quizEndTime;
		this.totalMarks = totalMarks;
		this.totalStudents = totalStudents;
		this.noOfStudentsTaken = noOfStudentsTaken;
		this.creationdate = creationdate;
		this.startDate = startDate;
		this.submissionDate = submissionDate;
		this.graceDate = graceDate;
		this.quizType = quizType;
		this.deleteQuiz = deleteQuiz;
	}
	
	public String getQuizId() {
		return quizId;
	}
	public void setQuizId(String quizId) {
		this.quizId = quizId;
	}
	public String getTeacherid() {
		return teacherid;
	}
	public void setTeacherid(String teacherid) {
		this.teacherid = teacherid;
	}
	public String getTeachername() {
		return teachername;
	}
	public void setTeachername(String teachername) {
		this.teachername = teachername;
	}
	public String getVideoId() {
		return videoId;
	}
	public void setVideoId(String videoId) {
		this.videoId = videoId;
	}
	public String getStandard() {
		return standard;
	}
	public void setStandard(String standard) {
		this.standard = standard;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getSection() {
		return section;
	}
	public void setSection(String section) {
		this.section = section;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getChooseCount() {
		return chooseCount;
	}
	public void setChooseCount(String chooseCount) {
		this.chooseCount = chooseCount;
	}
	public String getFillUpCount() {
		return fillUpCount;
	}
	public void setFillUpCount(String fillUpCount) {
		this.fillUpCount = fillUpCount;
	}
	public String getTrueOrFalseCount() {
		return trueOrFalseCount;
	}
	public void setTrueOrFalseCount(String trueOrFalseCount) {
		this.trueOrFalseCount = trueOrFalseCount;
	}
	public String getOneWordCount() {
		return oneWordCount;
	}
	public void setOneWordCount(String oneWordCount) {
		this.oneWordCount = oneWordCount;
	}
	public String getMaximumQuestion() {
		return maximumQuestion;
	}
	public void setMaximumQuestion(String maximumQuestion) {
		this.maximumQuestion = maximumQuestion;
	}
	public String getQuizTime() {
		return quizTime;
	}
	public void setQuizTime(String quizTime) {
		this.quizTime = quizTime;
	}
	public String getQuizStartTime() {
		return quizStartTime;
	}
	public void setQuizStartTime(String quizStartTime) {
		this.quizStartTime = quizStartTime;
	}
	public String getQuizEndTime() {
		return quizEndTime;
	}
	public void setQuizEndTime(String quizEndTime) {
		this.quizEndTime = quizEndTime;
	}
	public String getTotalMarks() {
		return totalMarks;
	}
	public void setTotalMarks(String totalMarks) {
		this.totalMarks = totalMarks;
	}
	public String getTotalStudents() {
		return totalStudents;
	}
	public void setTotalStudents(String totalStudents) {
		this.totalStudents = totalStudents;
	}
	public String getNoOfStudentsTaken() {
		return noOfStudentsTaken;
	}
	public void setNoOfStudentsTaken(String noOfStudentsTaken) {
		this.noOfStudentsTaken = noOfStudentsTaken;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getSubmissionDate() {
		return submissionDate;
	}
	public void setSubmissionDate(String submissionDate) {
		this.submissionDate = submissionDate;
	}
	public String getGraceDate() {
		return graceDate;
	}
	public void setGraceDate(String graceDate) {
		this.graceDate = graceDate;
	}
	public String getQuizType() {
		return quizType;
	}
	public void setQuizType(String quizType) {
		this.quizType = quizType;
	}
	public String getDeleteQuiz() {
		return deleteQuiz;
	}
	public void setDeleteQuiz(String deleteQuiz) {
		this.deleteQuiz = deleteQuiz;
	}

	public Date getCreationdate() {
		return creationdate;
	}

	public void setCreationdate(Date creationdate) {
		this.creationdate = creationdate;
	}
	
}
