package smartail.deepgrade.reports.videoDocument.data;

import java.util.Date;


public class QuizTracker {

	private String _id;
	private String studentId;
	private String name;
	private String rollNumber;
	private String standard;
	private String section;
	private String quizId;
	private String title;
	private String subject;
	private String maxques;
	private int marksScored;
	private Boolean videoFlag;
	private String timeTaken;
	private String completedFlag;
	private String archievedFlag;
	private Boolean watchFlag;
	private Date submissionDate;
	
	public QuizTracker(String _id, String studentId, String name, String rollNumber, String standard, String section,
			String quizId, String title, String subject, String maxques, int marksScored, Boolean videoFlag,
			String timeTaken, String completedFlag, String archievedFlag, Boolean watchFlag, Date submissionDate) {
		super();
		this._id = _id;
		this.studentId = studentId;
		this.name = name;
		this.rollNumber = rollNumber;
		this.standard = standard;
		this.section = section;
		this.quizId = quizId;
		this.title = title;
		this.subject = subject;
		this.maxques = maxques;
		this.marksScored = marksScored;
		this.videoFlag = videoFlag;
		this.timeTaken = timeTaken;
		this.completedFlag = completedFlag;
		this.archievedFlag = archievedFlag;
		this.watchFlag = watchFlag;
		this.submissionDate = submissionDate;
	}

	public String get_id() {
		return _id;
	}

	public void set_id(String _id) {
		this._id = _id;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(String rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getStandard() {
		return standard;
	}

	public void setStandard(String standard) {
		this.standard = standard;
	}

	public String getSection() {
		return section;
	}

	public void setSection(String section) {
		this.section = section;
	}

	public String getQuizId() {
		return quizId;
	}

	public void setQuizId(String quizId) {
		this.quizId = quizId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getMaxques() {
		return maxques;
	}

	public void setMaxques(String maxques) {
		this.maxques = maxques;
	}

	public int getMarksScored() {
		return marksScored;
	}

	public void setMarksScored(int marksScored) {
		this.marksScored = marksScored;
	}

	public Boolean getVideoFlag() {
		return videoFlag;
	}

	public void setVideoFlag(Boolean videoFlag) {
		this.videoFlag = videoFlag;
	}

	public String getTimeTaken() {
		return timeTaken;
	}

	public void setTimeTaken(String timeTaken) {
		this.timeTaken = timeTaken;
	}

	public String getCompletedFlag() {
		return completedFlag;
	}

	public void setCompletedFlag(String completedFlag) {
		this.completedFlag = completedFlag;
	}

	public String getArchievedFlag() {
		return archievedFlag;
	}

	public void setArchievedFlag(String archievedFlag) {
		this.archievedFlag = archievedFlag;
	}

	public Boolean getWatchFlag() {
		return watchFlag;
	}

	public void setWatchFlag(Boolean watchFlag) {
		this.watchFlag = watchFlag;
	}

	public Date getSubmissionDate() {
		return submissionDate;
	}

	public void setSubmissionDate(Date submissionDate) {
		this.submissionDate = submissionDate;
	}
	
	
	
}
