package smartail.deepgrade.reports.Quiz.data;

import java.util.List;

public class gettingdatalist {
	
	private int count;
	private List<gettingdata> list;
	
	public gettingdatalist() {}
	
	public gettingdatalist(String string) {}
	
	public gettingdatalist(int count, List<gettingdata> list) {
		super();
		this.count = count;
		this.list = list;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
	public List<gettingdata> getList() {
		return list;
	}
	public void setList(List<gettingdata> list) {
		this.list = list;
	}
	
}
