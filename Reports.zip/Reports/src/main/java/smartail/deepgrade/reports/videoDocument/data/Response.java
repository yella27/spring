package smartail.deepgrade.reports.videoDocument.data;


import java.util.List;

public class Response {

	private int videoCount;
	private List<VideoDetails> VideoDetails;
	private int documentCount;
	private List<DocumentDetails> DocumentDetails;
	private int viewedVideoCount;
	private List<VideoDetails> ViewedVideoDetails;
	
	public Response() {}

	public Response(int videoCount, List<smartail.deepgrade.reports.videoDocument.data.VideoDetails> videoDetails, int documentCount,
			List<smartail.deepgrade.reports.videoDocument.data.DocumentDetails> documentDetails, int viewedVideoCount,
			List<smartail.deepgrade.reports.videoDocument.data.VideoDetails> viewedVideoDetails) {
		super();
		this.videoCount = videoCount;
		VideoDetails = videoDetails;
		this.documentCount = documentCount;
		DocumentDetails = documentDetails;
		this.viewedVideoCount = viewedVideoCount;
		ViewedVideoDetails = viewedVideoDetails;
	}

	public Response(String string) {
		System.out.println(string);
	}

	public int getVideoCount() {
		return videoCount;
	}

	public void setVideoCount(int videoCount) {
		this.videoCount = videoCount;
	}

	public List<VideoDetails> getVideoDetails() {
		return VideoDetails;
	}

	public void setVideoDetails(List<VideoDetails> videoDetails) {
		VideoDetails = videoDetails;
	}

	public int getDocumentCount() {
		return documentCount;
	}

	public void setDocumentCount(int documentCount) {
		this.documentCount = documentCount;
	}

	public List<DocumentDetails> getDocumentDetails() {
		return DocumentDetails;
	}

	public void setDocumentDetails(List<DocumentDetails> documentDetails) {
		DocumentDetails = documentDetails;
	}

	public int getViewedVideoCount() {
		return viewedVideoCount;
	}

	public void setViewedVideoCount(int viewedVideoCount) {
		this.viewedVideoCount = viewedVideoCount;
	}

	public List<VideoDetails> getViewedVideoDetails() {
		return ViewedVideoDetails;
	}

	public void setViewedVideoDetails(List<VideoDetails> viewedVideoDetails) {
		ViewedVideoDetails = viewedVideoDetails;
	}
}
