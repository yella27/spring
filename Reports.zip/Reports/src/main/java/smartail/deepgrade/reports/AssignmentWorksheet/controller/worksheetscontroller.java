package smartail.deepgrade.reports.AssignmentWorksheet.controller;

import java.util.Date;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.WebClient;



import reactor.core.publisher.Flux;
import smartail.deepgrade.reports.AssignmentWorksheet.data.AssignmentResponse;

@RestController
public class worksheetscontroller {

	WebClient webclient;

	@GetMapping("/uploadedworksheet")
	public Flux<AssignmentResponse> uploaddata(@RequestParam(required = false, defaultValue = "All") String subject,
			@RequestParam(required = false, defaultValue = "All") String standard,
			@RequestParam(required = false, defaultValue = "All") String teacherId,
			@RequestParam(required = false, defaultValue = "All") String section,
			@RequestParam(required = false, defaultValue = "6 months ago") String duration) {

		System.out.println("Hello !");
		webclient = WebClient.builder().baseUrl("http://localhost:8080")
				.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE).build();

		try {

			System.out.println(subject + " " + standard + " " + teacherId + " " + section);
			if (!subject.equals("All") && standard.equals("All") && teacherId.equals("All") && section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("subject", subject)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			} else if (subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("standard", standard)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// teacher name
			else if (subject.equals("All") && standard.equals("All") && !teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters")
								.queryParam("teacherId", teacherId).queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// section
			else if (subject.equals("All") && standard.equals("All") && teacherId.equals("All")
					&& !section.equals("All")) {

				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("section", section)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// sub,tname
			else if (!subject.equals("All") && !teacherId.equals("All") && standard.equals("All")
					&& section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("subject", subject)
								.queryParam("teacherId", teacherId).queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}

//-					// sub,sec
			else if (!subject.equals("All") && !section.equals("All") && teacherId.equals("All")
					&& standard.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("subject", subject)
								.queryParam("section", section).queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}

//-					// std,tname
			else if (subject.equals("All") && section.equals("All") && !teacherId.equals("All")
					&& !standard.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("standard", standard)
								.queryParam("teacherId", teacherId).queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// sub,std
			else if (!subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("subject", subject)
								.queryParam("standard", standard).queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}

//-					// std,sec
			else if (subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("standard", standard)
								.queryParam("section", section).queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}

//-					// sec,tname
			else if (subject.equals("All") && standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters")
								.queryParam("teacherId", teacherId).queryParam("section", section)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// std,sub,tname
			else if (!subject.equals("All") && !standard.equals("All") && !teacherId.equals("All")
					&& section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("standard", standard)
								.queryParam("subject", subject).queryParam("teacherId", teacherId)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// sub,sec,std
			else if (!subject.equals("All") && !standard.equals("All") && teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("standard", standard)
								.queryParam("subject", subject).queryParam("section", section)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// sec,std,tname
			else if (subject.equals("All") && !standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("standard", standard)
								.queryParam("section", section).queryParam("teacherId", teacherId)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// tname,sub,sec
			else if (!subject.equals("All") && standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("section", section)
								.queryParam("subject", subject).queryParam("teacherId", teacherId)
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
//-					// std,sub,tname,sec
			else if (!subject.equals("All") && !standard.equals("All") && !teacherId.equals("All")
					&& !section.equals("All")) {
				return webclient.get()
						.uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters").queryParam("standard", standard)
								.queryParam("subject", subject).queryParam("teacherId", teacherId)
								.queryParam("section", section).queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			} else {
				return webclient
						.get().uri(uriBuilder -> uriBuilder.path("/uploadedDataWithFilters")
								.queryParam("duration", duration).build())
						.retrieve().bodyToFlux(AssignmentResponse.class);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return null;

	}

}
