package smartail.deepgrade.reports.AssignmentWorksheet.model;

public class StudentInfo {

	private String studentName; 
	private int averageMarks;
		
	public StudentInfo(String studentName, int averageMarks) {
		super();
		this.studentName = studentName;
		this.averageMarks = averageMarks;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public int getAverageMarks() {
		return averageMarks;
	}
	public void setAverageMarks(int averageMarks) {
		this.averageMarks = averageMarks;
	}
}
