package com.web1.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiFunctionWebClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
